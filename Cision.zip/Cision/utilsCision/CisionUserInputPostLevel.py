import requests
from pandas.io.json import json_normalize
from pandas import DataFrame
import pandas as pd 
import time
from datetime import datetime
import os.path
from dateutil import tz
import re
from datetime import datetime, timedelta
from datetime import date

#Not added for Time conversion from any time to CET dateconversion module need to be added later
#this method returns true if file exists
def checkFile(fn):
    return os.path.isfile(fn)


def historicDataRefresh(df):

    ''' Check for the file FirstExecution if the file is not present then it will ask for the no. of days 
    data need to be refresed but if the file is present it will only refresh the most recent data'''
    df = df
    path = 'temp'
    list_dir = []
    if(os.path.exists(path)):
       list_dir =  os.listdir(path)
    if(not os.path.exists(path)):
        os.mkdir('temp')
     #considering todays date and checking if the file is run once today or not
    if ('CisionPostLevel_'+date.today().strftime('%d_%m_%Y')+".txt" in list_dir):
        print('second Execution')
        #THIS LOGIC IS DIFFERENT as CSV was saving in 11/7/2020 and reading in 2020-07-11
        # df['date'] = df['date'].apply(lambda x: datetime.strptime(x,'%m/%d/%y').strftime('%Y-%m-%d'))
        #converting all values in date to one format
        
        for i in range(len(df['date'])):
            try:
                df['date'][i] = datetime.strptime(df['date'][i],'%m/%d/%y').strftime('%Y-%m-%d')
            except:
                #pass because its already in same format
                pass


        dates = df['date'].iloc[-1]

        #extracting date from datatime
        new_start_date = datetime.strptime(dates, '%Y-%m-%d') - timedelta(days=0)
        print('Refreshing data from: '+datetime.strftime(new_start_date,'%Y-%m-%d'))

        df['date'] = df['date'].apply(lambda x: datetime.strptime(x,'%Y-%m-%d'))
        df_modified = df[df['date'] < new_start_date]
        #converting date again to string format
        df_modified['date'] = df_modified['date'].apply(lambda x: datetime.strftime(x,'%Y-%m-%d'))
        sname = df_modified['searchName'].iloc[1]
        tup = (df_modified,datetime.strftime(new_start_date,'%Y-%m-%d'),sname)
        return tup

    else:
        #Create a file after 1st execution.
        file = open(os.path.join(path,"CisionPostLevel_"+date.today().strftime('%d_%m_%Y')+".txt"), 'w')
        file.write("First Execution")
        file.close()
        print('First execution')
        for i in range(len(df['date'])):
            try:
                df['date'][i] = datetime.strptime(df['date'][i],'%m/%d/%y').strftime('%Y-%m-%d')
            except:
                #pass because its already in same format
                pass
        # df['date'] = df['date'].apply(lambda x: datetime.strptime(x,'%m/%d/%y').strftime('%Y-%m-%d'))

        dates = df['date'].iloc[-1]
        #extracting date from datatime
        day = int(input('Number of days data need to be refreshed: '))
        new_start_date = datetime.strptime(dates ,'%Y-%m-%d') - timedelta(days=day)
        print('Refreshing data from: '+datetime.strftime(new_start_date,'%Y-%m-%d'))
        
        df['date'] = df['date'].apply(lambda x: datetime.strptime(x,'%Y-%m-%d'))
        df_modified = df[df['date'] < new_start_date]
        #converting date again to string format
        df_modified['date'] = df_modified['date'].apply(lambda x: datetime.strftime(x,'%Y-%m-%d'))
        sname = df_modified['searchName'].iloc[1]
        tup = (df_modified,datetime.strftime(new_start_date,'%Y-%m-%d'),sname)

        return tup


def returnUserInputsPostlevelCision():
    #if already have a file
    fname = input('Existing Post File: ')

    if(checkFile(fname)):
        df = pd.read_csv(fname)
        searchid_df = pd.read_csv('Search_ID_Dataset.csv')
        #this will return tuple of two values
        returned_data = historicDataRefresh(df)
        dfs = returned_data[0]
        startdate = returned_data[1]
        search_name = returned_data[2]
        # incrementing a day so that we dont have duplicate values 
        # startdate = (datetime.strptime(startdate,'%Y-%m-%d') + timedelta(days= 1)).strftime('%Y-%m-%d')+'T00:00:00.000Z'
        enddate = input('Enter Ending Date: ')
        enddate = datetime.strptime(enddate,'%d-%m-%Y').strftime('%Y-%m-%d')
        searchid = df['searchId'].iloc[-1]       

        tuple_return = (searchid,startdate,enddate,dfs,search_name,'File already present')

        return tuple_return

    else:
        #reading the csv file for selecting the project , topic (another module to create this topicID dataset)
        #DO NOT CHANGE THE NAME
        searchid_df = pd.read_csv('Search_ID_Dataset.csv')
        #input project name and then topic to get topic id under particualr project 
        user_searchname = input('Search Name: ') 
        #subseting DF
        searchid_df['condition'] = searchid_df.apply(lambda x: x['title']== user_searchname.strip() ,axis = 1)
        search_id = searchid_df[searchid_df['condition'] == True]['id']
        search_sid = ''
        search_name = ''
        for items in search_id.iteritems(): 
            search_sid = items[1]
        #to get the title also
        search_n = searchid_df[searchid_df['condition'] == True]['title']
        for items in search_n.iteritems():
            search_name = items[1]
        startdate = input('Enter Starting Date: ')
        #Converting to other format
        startdate = datetime.strptime(startdate,'%d-%m-%Y').strftime('%Y-%m-%d')

        enddate = input('Enter Ending Date: ')
        #Converting to other format
        enddate = datetime.strptime(enddate,'%d-%m-%Y').strftime('%Y-%m-%d')

        tuple_return = (search_sid,startdate,enddate,search_name)
        
        return tuple_return