import requests

#method to generate access_token, hardcoded the values for username and password
def accessToken():
    
    access_token = ''
    url = "https://api.trendkite.com/api/login"
    #DONOT CHANGE ANYTHING
    payload="{\"username\":\"murali.ravikumar@externals.adidas-group.com\",\"password\":\"passwordforcision@123\"}"
    headers = {
      'username': 'murali.ravikumar@externals.adidas-group.com',
      'password': 'passwordforcision@123',
      'Content-Type': 'text/plain',

    }

    response = requests.request("POST", url, headers=headers, data=payload)
    res = response.text
    #response was in string in dictionary format so eval will convert that string to dictionary
    access_token = eval(res)['access_token']
    
    return access_token