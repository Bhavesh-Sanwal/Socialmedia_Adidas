import requests
from pandas.io.json import json_normalize
from pandas import DataFrame
import pandas as pd 
import time
from datetime import datetime
import os.path
from dateutil import tz
import re
from datetime import datetime, timedelta
from datetime import date


#this method returns true if file exists
def checkFile(fn):
    return os.path.isfile(fn)


def historicDataRefresh(df):

    ''' Check for the file FirstExecution if the file is not present then it will ask for the no. of days 
    data need to be refresed but if the file is present it will only refresh the most recent data'''

    path = 'temp'
    list_dir = []
    if(os.path.exists(path)):
       list_dir =  os.listdir(path)
    if(not os.path.exists(path)):
        os.mkdir('temp')
     #considering todays date and checking if the file is run once today or not
    if ('CisionAggreLevel_'+date.today().strftime('%d_%m_%Y')+".txt" in list_dir):
        print('second Execution')
        dates = df['startDate'].iloc[-1]
        #extracting date from datatime
        dates = dates.split('T')[0]

        new_start_date = datetime.strptime(dates ,'%Y-%m-%d') - timedelta(days=0)
        print('Refreshing data from: '+datetime.strftime(new_start_date,'%Y-%m-%d'))
        #splitting x on . because of millsecond 
        df['startDate'] = df['startDate'].apply(lambda x: datetime.strptime(x.split('.')[0],'%Y-%m-%dT%H:%M:%S'))
        df_modified = df[df['startDate'] < new_start_date]
        #after removing the records converting back to the actual format
        df_modified['startDate'] = df_modified['startDate'].apply(lambda x: datetime.strftime(x,'%Y-%m-%dT%H:%M:%S'))
        df_modified['startDate'] = df_modified['startDate'].apply(lambda x: x+'.000Z')
        return df_modified

    else:
        #Create a file after 1st execution.
        file = open(os.path.join(path,"CisionAggreLevel_"+date.today().strftime('%d_%m_%Y')+".txt"), 'w')
        file.write("First Execution")
        file.close()
        print('First execution')

        dates = df['startDate'].iloc[-1]
        #extracting date from datatime
        dates = dates.split('T')[0]
        day = int(input('Number of days data need to be refreshed: '))
        new_start_date = datetime.strptime(dates ,'%Y-%m-%d') - timedelta(days=day)
        print('Refreshing data from: '+datetime.strftime(new_start_date,'%Y-%m-%d'))
        #splitting x on . because of millsecond 
        df['startDate'] = df['startDate'].apply(lambda x: datetime.strptime(x.split('.')[0],'%Y-%m-%dT%H:%M:%S'))
        df_modified = df[df['startDate'] < new_start_date]
        #after removing the records converting back to the actual format
        df_modified['startDate'] = df_modified['startDate'].apply(lambda x: datetime.strftime(x,'%Y-%m-%dT%H:%M:%S'))
        df_modified['startDate'] = df_modified['startDate'].apply(lambda x: x+'.000Z')

        return df_modified




def returnUserInputsAggrelevelCision():

    #if already have a file
    fname = input('Existing Aggregated File: ')

    if(checkFile(fname)):
        df = pd.read_csv(fname)
        
        dfs = historicDataRefresh(df)

        startdate = dfs['startDate'].iloc[-1]
        # incrementing a day so that we dont have duplicate values 
        # startdate = (datetime.strptime(startdate,'%Y-%m-%d') + timedelta(days= 1)).strftime('%Y-%m-%d')+'T00:00:00.000Z'
        enddate = input('Enter Ending Date: ')
        enddate = datetime.strptime(enddate,'%d-%m-%Y').strftime('%Y-%m-%d')+'T23:59:59.000Z'
        searchid = df['searchId'].iloc[-1]        

        tuple_return = (searchid,startdate,enddate,dfs,'File already present')

        return tuple_return

    else:
        #reading the csv file for selecting the project , topic (another module to create this topicID dataset)
        #DO NOT CHANGE THE NAME
        searchid_df = pd.read_csv('Search_ID_Dataset.csv')
        #input project name and then topic to get topic id under particualr project 
        user_searchname = input('Search Name: ') 
        #subseting DF
        searchid_df['condition'] = searchid_df.apply(lambda x: x['title']== user_searchname.strip() ,axis = 1)
        search_id = searchid_df[searchid_df['condition'] == True]['id']
        search_sid = ''
        for items in search_id.iteritems(): 
            search_sid = items[1]
        startdate = input('Enter Starting Date: ')
        #Converting to other format
        startdate = datetime.strptime(startdate,'%d-%m-%Y').strftime('%Y-%m-%d')

        enddate = input('Enter Ending Date: ')
        #Converting to other format
        enddate = datetime.strptime(enddate,'%d-%m-%Y').strftime('%Y-%m-%d')
        tuple_return = (search_sid,startdate,enddate)
        
        return tuple_return