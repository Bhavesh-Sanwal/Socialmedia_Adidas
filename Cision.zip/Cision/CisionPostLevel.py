import requests 
import pandas as pd
import time

from utilsCision.accesstoken import accessToken


def postLevel(search_id,start_date,end_date,search_name):
    
    df_post = pd.DataFrame(columns=['Tool','Domain','searchId','searchName','date','mediaType','mediaOutlet','title','link','url',
                                   'author','sentiment','adEquivalency','seoImpact','readership','impactScore','shares',
                                    'socialFacebook','socialGoogleplus','socialTwitter','socialPinterest','socialLinkedin',
                                   'sessions','pageViews','avgSessionDuration','percentNewSessions','newUsers',
                                   'bounceRate','pageViewsPerSession','goalCompletions','goalValue','transactionRevenue',
                                   'country','state','city'])
    
    #coming from utilsCision.acccesstoken
    auth_token = accessToken()
    
    headers = {
        'X-Auth-Token': auth_token ,
    }

    searchid=3607569
    range_start = start_date +'T00:00:00.000Z'
    range_end = end_date + 'T23:59:59.000Z'
    
    response_list_flag = True
    num = 0
    count =0
    page_num  = 0
    while(response_list_flag):
        
        url = "https://api.trendkite.com/api/v2/totalmentions?s="+str(searchid)+"&range-start="+range_start+"&range-end="+range_end+"&page-num="+str(page_num)+"&page-size=500&sort=asc"
        page_num +=1
        response = requests.get(url, headers=headers)
        data = response.json()
        #we dont have any data left to extract
        if(len(data) == 0):
            response_list_flag = False
        else:
            #new start date will be last date from the value
            #converting date from 08/19/20 to 2020-08-19
#             range_start = datetime.strptime(data[-1]['date'],'%m/%d/%y').strftime('%Y-%m-%d')+'T00:00:00.000Z'
            print("Page No.:",page_num)
            print('Records retrived:',len(data))
            #columns from DF stored into list
            key_list = []
            for i in df_post.keys():
                key_list.append(i)

            #creating the data set
            for i in range(len(data)):
                df_post.loc[num]= ''
                df_post['Tool'][num] = 'Cision'
                df_post['Domain'][num] = 'PR'
                df_post['searchId'][num] = searchid
                df_post['searchName'][num] = search_name
                for key, value in data[i].items():
                    if(key in key_list):
                        df_post[key][num] = data[i][key]

                num +=1
        count +=1
        print('Iteration Count:', count)
        time.sleep(10)
    
    return df_post


#for historic data

def historicpostLevel(search_id,start_date,end_date,df,search_name):
    
    auth_token = accessToken()
    
    headers = {
        'X-Auth-Token': auth_token ,
    }

    #change this hard coded value to search_id
    searchid=3607569
    range_start = start_date +'T00:00:00.000Z'
    range_end = end_date + 'T23:59:59.000Z'
    
    response_list_flag = True
    
    df_post = df
    num = int(df.shape[0])
    
    count =0
    page_num  = 0
    while(response_list_flag):
        
        url = "https://api.trendkite.com/api/v2/totalmentions?s="+str(searchid)+"&range-start="+range_start+"&range-end="+range_end+"&page-num="+str(page_num)+"&page-size=500&sort=asc"
        page_num +=1
        response = requests.get(url, headers=headers)
        data = response.json()
        #we dont have any data left to extract
        if(len(data) == 0):
            response_list_flag = False
        else:
            #new start date will be last date from the value
            #converting date from 08/19/20 to 2020-08-19
#             range_start = datetime.strptime(data[-1]['date'],'%m/%d/%y').strftime('%Y-%m-%d')+'T00:00:00.000Z'
            print("Page No.:",page_num)
            print('Records retrived:',len(data))
            #columns from DF stored into list
            key_list = []
            for i in df_post.keys():
                key_list.append(i)

            #creating the data set, data is being stored in 
            for i in range(len(data)):
                df_post.loc[num]= ''
                df_post['Tool'][num] = 'Cision'
                df_post['Domain'][num] = 'PR'
                df_post['searchId'][num] = searchid
                df_post['searchName'][num] = search_name
                for key, value in data[i].items():
                    if(key in key_list):
                        df_post[key][num] = data[i][key]

                num +=1
        count +=1
        print('Iteration Count:', count)
        time.sleep(10)
    
    return df_post
