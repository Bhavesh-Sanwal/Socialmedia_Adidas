from datetime import datetime, timedelta
import re
import pandas as pd
import time
import requests

#method to generate access_token, hardcoded the values for username and password
def accessToken():
    
    access_token = ''
    url = "https://api.trendkite.com/api/login"
    #DONOT CHANGE ANYTHING
    payload="{\"username\":\"murali.ravikumar@externals.adidas-group.com\",\"password\":\"passwordforcision@123\"}"
    headers = {
      'username': 'murali.ravikumar@externals.adidas-group.com',
      'password': 'passwordforcision@123',
      'Content-Type': 'text/plain',

    }

    response = requests.request("POST", url, headers=headers, data=payload)
    res = response.text
    #response was in string in dictionary format so eval will convert that string to dictionary
    access_token = eval(res)['access_token']
    
    return access_token

def searchidData():
    auth_token = accessToken()
    df = pd.DataFrame(columns=['id','title','taxonomy'])
    
    headers = {
      'X-Auth-Token': auth_token ,
    }

    url = "https://api.trendkite.com/api/v2/searches"

    response = requests.get(url, headers=headers)

    data = response.json()
    datalist = data['searches']
    #creating dataset of id and title from json response
    num = 0
    for i in datalist:
        df.loc[num]=''
        for key,value in i.items():
            df[key][num] = i[key]
            
        num +=1
    
    df.to_csv('Search_ID_Dataset.csv',index = False)
        