from datetime import datetime, timedelta
import re
import pandas as pd
import time
import requests
from utilsCision.accesstoken import accessToken


#method to create data day wise 
def dayLevelAggre(search_id, rangestart, rangeend):

    auth_token = accessToken()
    start_date = datetime.strptime(rangestart,'%Y-%m-%d')
    
    end_date = datetime.strptime(rangeend,'%Y-%m-%d')
    # calculating difference between startdate and enddate
    date_range = end_date - start_date

    date_range = int(str(date_range).split()[0])

    range_start = '' 
    range_end =''

    Aggregated_stats = []
    #creating day wise data from start and end date
    count = 0
    for i in range(0,date_range + 1):
        #adding the days to start date
        range_start = start_date + timedelta(days= i)
        range_start = re.sub(' ','T',datetime.strftime(range_start,'%Y-%m-%d 00:00:00'))+".000Z"
        range_end =re.sub('00:00:00.000Z','23:59:59.000Z',range_start)

        stats = requests.get('http://api.trendkite.com/api/v2/stats?s='+str(search_id)+'&range-start='+range_start+'&range-end='+range_end,headers={'X-Auth-Token': auth_token})
        count +=1
        if(count % 10 == 0):
            time.sleep(60)

        Aggregated_stats.append(stats.json())

        print('Appending entries', i)

    return Aggregated_stats

def aggregatedData(search_id, rangestart, rangeend):

    Aggregated_stats = dayLevelAggre(search_id,rangestart,rangeend)
    
    df_aggr = pd.DataFrame(columns=['Tool','Domain','searchId','searchName','startDate','endDate','ave_Newspaper',
                                   'ave_Blog','ave_Television','totalAVE','readership_Newspaper',
                                   'readership_Blog','readership_Television','totalReadership','totalMentions',
                                   'socialFacebookComments','socialFacebookLike','socialFacebookShare',
                                    'socialFacebookTotal','socialGoogleplus',
                                    'socialLinkedin','socialPinterest','socialReddit',
                                    'socialSum','socialTwitter',
                                   'totalSocialShares'])
    
    print('Creating dataset..')
    
    num = 0
    for k in Aggregated_stats:
        agger_data = k

        for i in range(len(agger_data)):
            df_aggr.loc[num]=''
            df_aggr['Tool'][num] = 'Cision'
            df_aggr['Domain'][num] = 'PR'
            df_aggr['searchId'][num] = agger_data[i]['searchId']
            df_aggr['searchName'][num] = agger_data[i]['searchName']
            df_aggr['startDate'][num] = agger_data[i]['startDate']
            df_aggr['endDate'][num] = agger_data[i]['endDate']

            temp_data = agger_data[i]['data']
            for j in range(len(temp_data)):
                if('ave' in temp_data[j].keys()):
                    df_aggr['ave_Newspaper'][num] = temp_data[j]['ave'][0]['value']
                    df_aggr['ave_Blog'][num] = temp_data[j]['ave'][1]['value']
                    df_aggr['ave_Television'][num] = temp_data[j]['ave'][2]['value']
                    df_aggr['totalAVE'][num] = temp_data[j]['totalAVE']
                if('readership' in temp_data[j].keys()):
                    df_aggr['readership_Newspaper'][num] = temp_data[j]['readership'][0]['value']
                    df_aggr['readership_Blog'][num] = temp_data[j]['readership'][1]['value']
                    df_aggr['readership_Television'][num] = temp_data[j]['readership'][2]['value']
                    df_aggr['totalReadership'][num] = temp_data[j]['totalReadership']
                if('totalMentions' in temp_data[j].keys()):
                    df_aggr['totalMentions'][num] = temp_data[j]['totalMentions']
                if('socialShares' in temp_data[j].keys()):
                    for key,value in temp_data[j]['socialShares'].items():
                        df_aggr[key][num] = temp_data[j]['socialShares'][key]
                    df_aggr['totalSocialShares'][num] = temp_data[j]['totalSocialShares']

        num+=1  
            
    return df_aggr




# When have historic data
def histo_aggregatedData(search_id, rangestart, rangeend, df):
    rangestart = rangestart.split('T')[0]
    rangeend = rangeend.split('T')[0]
    Aggregated_stats = dayLevelAggre(search_id,rangestart,rangeend)
    
    print('Creating dataset..')

    #new num to start from already present database
    num = int(df.shape[0])
    df_aggr = df
    for k in Aggregated_stats:
        agger_data = k

        for i in range(len(agger_data)):
            df_aggr.loc[num]=''
            df_aggr['Tool'][num] = 'Cision'
            df_aggr['Domain'][num] = 'PR'
            df_aggr['searchId'][num] = agger_data[i]['searchId']
            df_aggr['searchName'][num] = agger_data[i]['searchName']
            df_aggr['startDate'][num] = agger_data[i]['startDate']
            df_aggr['endDate'][num] = agger_data[i]['endDate']

            temp_data = agger_data[i]['data']
            for j in range(len(temp_data)):
                if('ave' in temp_data[j].keys()):
                    df_aggr['ave_Newspaper'][num] = temp_data[j]['ave'][0]['value']
                    df_aggr['ave_Blog'][num] = temp_data[j]['ave'][1]['value']
                    df_aggr['ave_Television'][num] = temp_data[j]['ave'][2]['value']
                    df_aggr['totalAVE'][num] = temp_data[j]['totalAVE']
                if('readership' in temp_data[j].keys()):
                    df_aggr['readership_Newspaper'][num] = temp_data[j]['readership'][0]['value']
                    df_aggr['readership_Blog'][num] = temp_data[j]['readership'][1]['value']
                    df_aggr['readership_Television'][num] = temp_data[j]['readership'][2]['value']
                    df_aggr['totalReadership'][num] = temp_data[j]['totalReadership']
                if('totalMentions' in temp_data[j].keys()):
                    df_aggr['totalMentions'][num] = temp_data[j]['totalMentions']
                if('socialShares' in temp_data[j].keys()):
                    for key,value in temp_data[j]['socialShares'].items():
                        df_aggr[key][num] = temp_data[j]['socialShares'][key]
                    df_aggr['totalSocialShares'][num] = temp_data[j]['totalSocialShares']

        num+=1
    #setting searchId as index only to drop duplicates otherwise we need to save df and then read followed 
    #by droping duplicates.
    # df_aggr.set_index('searchId',inplace=True)
    # df_aggr.drop_duplicates(inplace = True, keep = 'first')
    return df_aggr