### cision imports 
from ID.CisionSearchIDdataset import searchidData
# from utils.Cisionaccesstoken import accessToken
from AggregatedData.AggreCision import aggregatedData, histo_aggregatedData
from PostData.CisionPostLevel import postLevel, historicpostLevel
from utils.CisionUserInputAggre import returnUserInputsAggrelevelCision
from utils.CisionUserInputPostLevel import returnUserInputsPostlevelCision

#talkwalker import 
from ID.TopicDatasetTalkwalker import topic_dataset
from utils.TalkwalkerUserInputFeatureAggre import returnUserInputs
from utils.TalkwalkerUserInputFeaturePostlevel import returnUserInputsPostlevel
from AggregatedData.AggregatedDataTalkwalker import agg_histogram, historic_agg_histogram
from PostData.TalkwalkerPostLevel import api,APIcall

#Crowdtangle Imports
from ID.TopicDatasetCT import topic_datasetCT
from utils.CrowdtangleUserInputFile import CTreturnUserInputsPostlevel
from PostData.CrowdTanglePostLevel import CTapi,CTAPIcall
from datetime import datetime
import pandas as pd
import os.path

import warnings
warnings.filterwarnings("ignore")

#Globally used variables
startdate = ''
enddate = ''
Talkwalker_Aggre_Data = None
Talkwalker_Post_Data = None
Cision_Aggre_Data = None
Cision_Post_Data = None
Crowdtangle_Post_Data = None


print('''Enter file name already created or if not, provide the new file name with out date
e.g (without date) Talkwalker_aggre or Talkwalker_post or Cision_aggree
(If already have a file ) provide the extension also Talkwalker_aggre24-11-2020.csv''')

###############    TALKWALKER INPUTS    ###############
#######################################################

#access token for Talkwalker
access_token = 'c83d2608-85b7-4dfb-aecf-a868bb4e0529_IoAYmOAYARaeHP1KHsfrDyLXjakhY6PFqIvxTL8oP8hVATahS1b8cyMSyYhOAkdul-cgNAPUFXnShruAiVldWNa.a5hlpsS5kdxmzdsvd5QwiJRPkWvHK2l6-8FJC5GhgcG6cwlwkpBcgyP.-1-9MrPtxN71Lj4lGmD7br6bPgI'

#Refreshing topic data set
#topic_dataset(access_token)

print('Talkwalker:')
#TAKING USER INPUTS


tw_Aggre_exist_file = input('Existing Talkwalker Aggregated File: ')
tw_Post_exist_file = input('Existing Talkwalker Post File: ')

# Check if the file is already present than only ask for the end date if not then ask for start and end dates
if(os.path.isfile('./DATASETS/'+tw_Aggre_exist_file) and os.path.isfile('./DATASETS/'+tw_Post_exist_file)):
    print('Post and Aggregated files are already Present')
    user_projectname = input('Talkwalker Project Name: ') 
    user_topic = input('Talkwalker User Topic: ')
    startdate =''
    enddate = input('End Date:')

else:
    user_projectname = input('Talkwalker Project Name: ') 
    user_topic = input('Talkwalker User Topic: ')
    startdate = input('Start Date:')
    enddate = input('End Date:')


#passing projectname and topic to Aggregated & post level talkwalker codes
Talkwalker_user_input_tuple = returnUserInputs(user_projectname,user_topic,startdate,enddate,tw_Aggre_exist_file)
print('-----------------------------------')
print('Talkwalker Inputs for Post Level:')
print('-----------------------------------')
Talkwalker_postlevel = returnUserInputsPostlevel(user_projectname,user_topic,startdate,enddate,tw_Post_exist_file)




#################    CISION INPUTS    #################
#######################################################

#Refreshing search ID data sets for Cision
searchidData()


print('Cision:')

# #TAKING USER INPUTS
# '''enter file name already created or if not, provide the new file name with out date
# e.g (without date) Talkwalker_aggre or Talkwalker_post or Cision_aggree
# (If already have a file ) provide the extension also .csv'''

ct_Aggre_exist_file = input('Existing Cision Aggregated File: ')
ct_Post_exist_file = input('Existing Cision Post File: ')

if(os.path.isfile('./DATASETS/'+ct_Aggre_exist_file) and os.path.isfile('./DATASETS/'+ct_Post_exist_file)):
    print('Post and Aggregated files are already Present')
    searchname = input('Cision Search Name: ')
    cta_name = input('Cision CTA Name: ')
    #startdate and eanddate are set while runing the code for talkwalker
    Cision_startdate = ''
    Cision_enddate = enddate

    
else:
    searchname = input('Cision Search Name: ')
    cta_name = input('Cision CTA Name: ')
    #startdate and eanddate are set while runing the code for talkwalker
    Cision_startdate = startdate
    Cision_enddate = enddate

#passing projectname and topic to Aggregated & post level Cision codes
Cision_user_input_tuple = returnUserInputsAggrelevelCision(searchname,Cision_startdate,Cision_enddate,ct_Aggre_exist_file,cta_name)
print('-------------------------------')
print('Cision Inputs for Post Level:')
print('-------------------------------')
#post level CTA included
Cision_user_input_tuple_Post = returnUserInputsPostlevelCision(searchname,Cision_startdate,Cision_enddate,ct_Post_exist_file,cta_name)




#################    CrowdTangle INPUTS    #################
############################################################
print('CrowdTangle:')

#access Token for FB and IG
ig_access_token = 'l4cNmVIw9vt5l3W1mbkW3bNjfyJZZ1tBIIZclNiF'
fb_access_token='Tjy1H6PbWdH8KhCbQSxRqV6tuscUBde0ovgEHA0S'
#Creating the TopicIDs_CrowdTangle.csv for first time
 
topic_datasetCT(ig_access_token,fb_access_token)

#file name for Crowdtangle
c_Post_exist_file = input('Existing Crowtangle Post File: ')

if(os.path.isfile('./DATASETS/'+c_Post_exist_file)):
    print('Post files are already Present')
    ct_searchname = input('Crowdtangle Saved Search Name: ')
    #startdate and eanddate are set while runing the code for talkwalker
    Crowdtangle_startdate = ''

    Crowdtangle_enddate = datetime.strptime(enddate ,'%d-%m-%Y').strftime('%Y-%m-%d')+' 23:59:59'


else:
    ct_searchname = input('Crowdtangle Saved Search Name: ')
    #startdate and eanddate are set while runing the code for talkwalker
    Crowdtangle_startdate = datetime.strptime(startdate ,'%d-%m-%Y').strftime('%Y-%m-%d')+' 00:00:00'
    Crowdtangle_enddate = datetime.strptime(enddate ,'%d-%m-%Y').strftime('%Y-%m-%d')+' 23:59:59'

    
Crowdtangle_postlevel = CTreturnUserInputsPostlevel(ct_searchname,Crowdtangle_startdate,Crowdtangle_enddate,c_Post_exist_file)

print('\n\n')
print('#################################################################################################\n')
print('DATA EXTRACTING FOR TALKWALKER')


## FOR TALKWALKER
if(Talkwalker_user_input_tuple[-1] == 'File already present' and Talkwalker_postlevel[-1] == 'File already present'):
    ## VALUES FOR HISTORIC AGGREGATED CALLS
    p= str(Talkwalker_user_input_tuple[0])
    t= str(Talkwalker_user_input_tuple[1])
    min_date_epoch= str(Talkwalker_user_input_tuple[2])
    max_date_epoch= str(Talkwalker_user_input_tuple[3])
    df = Talkwalker_user_input_tuple[4]
    tname = Talkwalker_user_input_tuple[5]
    
    #Return the DF
    Talkwalker_Aggre_Data = historic_agg_histogram(access_token,df,tname,min_date= min_date_epoch,max_date = max_date_epoch ,tid = t, pid= p)
    
    df = Talkwalker_postlevel[0]
    pid = Talkwalker_postlevel[1]
    tid = Talkwalker_postlevel[2]
    published_startdate = Talkwalker_postlevel[3]
    published_enddate = Talkwalker_postlevel[4]
    user_topic = Talkwalker_postlevel[5]
    
    #for historic data
    Talkwalker_Post_Data = APIcall(access_token,df,user_topic,published_startdate,published_enddate,pid,tid)
    
    #Make sure you have DATASETS folder created explicitly
    dirpath = './DATASETS/'
    Talkwalker_Post_Data.to_csv(dirpath+tw_Post_exist_file,index = False)
    Talkwalker_Aggre_Data.to_csv(dirpath+tw_Aggre_exist_file,index = False)
    print('File Saved!!')



else:
    '''Both Aggregated and Post level Data is retrieved '''
    
    ## VALUES FOR NEW AGGREGATED CALLS
    p= Talkwalker_user_input_tuple[0]
    t= Talkwalker_user_input_tuple[1]
    min_date_epoch= Talkwalker_user_input_tuple[2]
    max_date_epoch= Talkwalker_user_input_tuple[3]
    tname = Talkwalker_user_input_tuple[4]
    
    Talkwalker_Aggre_Data = agg_histogram(access_token,tname,min_date = str(min_date_epoch),max_date = str(max_date_epoch) ,tid = str(t), pid= str(p))
    
    
    pid = Talkwalker_postlevel[0]
    tid = Talkwalker_postlevel[1]
    published_startdate = Talkwalker_postlevel[2]
    published_enddate = Talkwalker_postlevel[3]
    user_topic = Talkwalker_postlevel[4]
    
    
    Talkwalker_Post_Data = api(access_token,user_topic,published_startdate,published_enddate,pid,tid)

    #Make sure you have DATASETS folder created explicitly
    dirpath = './DATASETS/'
    Talkwalker_Post_Data.to_csv(dirpath+tw_Post_exist_file+enddate+'.csv',index = False)
    Talkwalker_Aggre_Data.to_csv(dirpath+tw_Aggre_exist_file+enddate+'.csv',index = False)
    print('File Saved!!')   



print('\n\n')
print('#################################################################################################\n')
print('DATA EXTRACTING FOR CISION')



#For CISION
''' FOR CTA we need to create a new Excel manually'''
if(Cision_user_input_tuple[-1] == 'File already present' and Cision_user_input_tuple_Post[-1] == 'File already present'):
    #VALUES FOR HISTORIC AGGREGATED AND POST LEVEL CALLS
    search_id = '3722426'
    rangestart = Cision_user_input_tuple[1]
    rangeend = Cision_user_input_tuple[2]
    df = Cision_user_input_tuple[3]
    cid = Cision_user_input_tuple[4]
    cdf = Cision_user_input_tuple[5]

    Cision_Aggre_Data = histo_aggregatedData(search_id, rangestart, rangeend, df,blean= 'FALSE')
    Cision_CTAAggre_Data = histo_aggregatedData(cid, rangestart, rangeend, cdf,blean= 'TRUE')

    #Post Level
    #search_id = Cision_user_input_tuple_Post[0]
    post_search_id = '3722426'
    cta_search_id = Cision_user_input_tuple_Post[1]
    post_rangestart = Cision_user_input_tuple_Post[2]
    cta_rangestart = Cision_user_input_tuple_Post[3]
    rangeend = Cision_user_input_tuple_Post[4]
    postdf = Cision_user_input_tuple_Post[5]
    ctadf = Cision_user_input_tuple_Post[6]
    post_search_name = Cision_user_input_tuple_Post[7]
    cta_search_name = Cision_user_input_tuple_Post[8]
    
    Cision_Post_Data = historicpostLevel(post_search_id, post_rangestart, rangeend, postdf,post_search_name,blean='FALSE')
    Cision_CTAPost_Data = historicpostLevel(cta_search_id, cta_rangestart, rangeend, ctadf,cta_search_name,blean = 'TRUE')
    
    # As we are getting two formats so converting them to '%m/%d/%y' for post and cta
    Cision_Post_Data['date'] = pd.to_datetime(Cision_Post_Data['date'])
    Cision_Post_Data['date'] = Cision_Post_Data['date'].apply(lambda x: datetime.strftime(x,'%m/%d/%Y'))
    Cision_CTAPost_Data['date'] = pd.to_datetime(Cision_CTAPost_Data['date'])
    Cision_CTAPost_Data['date'] = Cision_CTAPost_Data['date'].apply(lambda x: datetime.strftime(x,'%m/%d/%Y'))

    #droping date,negativempositive,neutral columns are they will be created again in case of historic data    
    Cision_Aggre_Data = Cision_Aggre_Data.drop(['Date','Negative','Positive','Neutral'],axis = 1)
    Cision_CTAAggre_Data = Cision_CTAAggre_Data.drop(['Date','Negative','Positive','Neutral'],axis = 1)

    
    #creating seperate column Date in aggregated data other than startdate and enddate
    Cision_Aggre_Data['Date'] = Cision_Aggre_Data['startDate'].apply(lambda x: x.split('T')[0])
    Cision_Aggre_Data['Date'] = Cision_Aggre_Data['Date'].apply(lambda x: datetime.strptime(x,'%Y-%m-%d'))
    Cision_Aggre_Data['Date'] = Cision_Aggre_Data['Date'].apply(lambda x: x.strftime('%m/%d/%Y'))


    #forCTA
    #creating seperate column Date in aggregated data other than startdate and enddate
    Cision_CTAAggre_Data['Date'] = Cision_CTAAggre_Data['startDate'].apply(lambda x: x.split('T')[0])
    Cision_CTAAggre_Data['Date'] = Cision_CTAAggre_Data['Date'].apply(lambda x: datetime.strptime(x,'%Y-%m-%d'))
    Cision_CTAAggre_Data['Date'] = Cision_CTAAggre_Data['Date'].apply(lambda x: x.strftime('%m/%d/%Y'))


    #grouping the data
    grouped_data = Cision_Post_Data.groupby(['date','sentiment'])['sentiment'].count()
    grouped_data_CTA = Cision_CTAPost_Data.groupby(['date','sentiment'])['sentiment'].count()


    stackdf = pd.DataFrame(grouped_data)
    stackdf_CTA = pd.DataFrame(grouped_data_CTA)

    #after grouping we get stacked data so unstacking it 
    stackdf = stackdf.unstack()
    stackdf_CTA = stackdf_CTA.unstack()
    
    
    stackdf = stackdf.sentiment.rename_axis([None], axis=1)
    Cision_Aggre_Data = pd.merge(Cision_Aggre_Data,stackdf,left_on='Date',right_on='date',how='left')
    Cision_Aggre_Data = Cision_Aggre_Data.rename(columns={'positive':'Positive','negative':'Negative','neutral':'Neutral'})
    Cision_Aggre_Data['Positive'] = Cision_Aggre_Data['Positive'].fillna(0)
    Cision_Aggre_Data['Negative'] = Cision_Aggre_Data['Negative'].fillna(0)
    Cision_Aggre_Data['Neutral'] = Cision_Aggre_Data['Neutral'].fillna(0)
    
    
    #forCTA
    stackdf_CTA = stackdf_CTA.sentiment.rename_axis([None], axis=1)
    Cision_CTAAggre_Data = pd.merge(Cision_CTAAggre_Data,stackdf_CTA,left_on='Date',right_on='date',how='left')
    Cision_CTAAggre_Data = Cision_CTAAggre_Data.rename(columns={'positive':'Positive','negative':'Negative','neutral':'Neutral'})
    Cision_CTAAggre_Data['Positive'] = Cision_CTAAggre_Data['Positive'].fillna(0)
    Cision_CTAAggre_Data['Negative'] = Cision_CTAAggre_Data['Negative'].fillna(0)
    Cision_CTAAggre_Data['Neutral'] = Cision_CTAAggre_Data['Neutral'].fillna(0)
    
    
      #Appending CTA aggregated data to Aggregated data
    Cision_Aggre_Data = Cision_Aggre_Data.append(Cision_CTAAggre_Data,ignore_index=True)  
    #appending CTA post data to normal search post level data
    Cision_Post_Data = Cision_Post_Data.append(Cision_CTAPost_Data,ignore_index=True)
     #saving the dataset created to DATASETS folder
    #Make sure you have DATASETS folder created explicitly
    dirpath = './DATASETS/'
    Cision_Post_Data.to_csv(dirpath+ct_Post_exist_file,index = False,date_format='%m/%d/%Y')
    Cision_Aggre_Data.to_csv(dirpath+ct_Aggre_exist_file,index = False,date_format='%m/%d/%Y')
    print('File Saved!!')   
    

else:
    '''Both Aggregated and Post level Data is retrieved '''
    #search_id = Cision_user_input_tuple_Post[0]
    search_id = '3722426'
    rangestart = Cision_user_input_tuple[1]
    rangeend = Cision_user_input_tuple[2]
    cid = Cision_user_input_tuple[3]
    
    Cision_Aggre_Data = aggregatedData(search_id, rangestart, rangeend,blean='FALSE')
    Cision_CTAAggre_Data = aggregatedData(cid, rangestart, rangeend,blean='TRUE')
      
    #post level
    #search_id = Cision_user_input_tuple_Post[0]
    search_id = '3722426'
    rangestart = Cision_user_input_tuple_Post[1]
    rangeend = Cision_user_input_tuple_Post[2]
    search_name = Cision_user_input_tuple_Post[3]
    ctaid = Cision_user_input_tuple_Post[4]
    cname = Cision_user_input_tuple_Post[5]
    
    Cision_Post_Data = postLevel(search_id, rangestart, rangeend,search_name,blean='FALSE')
    Cision_CTAPost_Data = postLevel(ctaid, rangestart, rangeend,cname,blean='TRUE')
    
    
    #changing time to same formats from '11/1/2020' to '11/01/2020'
    Cision_Post_Data['date'] = Cision_Post_Data['date'].apply(lambda x: datetime.strptime(x,'%m/%d/%y'))
    Cision_Post_Data['date'] = Cision_Post_Data['date'].apply(lambda x: x.strftime('%m/%d/%Y'))
    
    #for CTA
    #changing time to same formats from '11/1/2020' to '11/01/2020'
    Cision_CTAPost_Data['date'] = Cision_CTAPost_Data['date'].apply(lambda x: datetime.strptime(x,'%m/%d/%y'))
    Cision_CTAPost_Data['date'] = Cision_CTAPost_Data['date'].apply(lambda x: x.strftime('%m/%d/%Y'))
    
    #creating seperate column Date in aggregated data other than startdate and enddate
    Cision_Aggre_Data['Date'] = Cision_Aggre_Data['startDate'].apply(lambda x: x.split('T')[0])
    Cision_Aggre_Data['Date'] = Cision_Aggre_Data['Date'].apply(lambda x: datetime.strptime(x,'%Y-%m-%d'))
    Cision_Aggre_Data['Date'] = Cision_Aggre_Data['Date'].apply(lambda x: x.strftime('%m/%d/%Y'))


    #forCTA
    #creating seperate column Date in aggregated data other than startdate and enddate
    Cision_CTAAggre_Data['Date'] = Cision_CTAAggre_Data['startDate'].apply(lambda x: x.split('T')[0])
    Cision_CTAAggre_Data['Date'] = Cision_CTAAggre_Data['Date'].apply(lambda x: datetime.strptime(x,'%Y-%m-%d'))
    Cision_CTAAggre_Data['Date'] = Cision_CTAAggre_Data['Date'].apply(lambda x: x.strftime('%m/%d/%Y'))


    #grouping the data
    grouped_data = Cision_Post_Data.groupby(['date','sentiment'])['sentiment'].count()
    grouped_data_CTA = Cision_CTAPost_Data.groupby(['date','sentiment'])['sentiment'].count()


    stackdf = pd.DataFrame(grouped_data)
    stackdf_CTA = pd.DataFrame(grouped_data_CTA)

    #after grouping we get stacked data so unstacking it 
    stackdf = stackdf.unstack()
    stackdf_CTA = stackdf_CTA.unstack()
    
    
    stackdf = stackdf.sentiment.rename_axis([None], axis=1)
    Cision_Aggre_Data = pd.merge(Cision_Aggre_Data,stackdf,left_on='Date',right_on='date',how='left')
    Cision_Aggre_Data = Cision_Aggre_Data.rename(columns={'positive':'Positive','negative':'Negative','neutral':'Neutral'})
    Cision_Aggre_Data['Positive'] = Cision_Aggre_Data['Positive'].fillna(0)
    Cision_Aggre_Data['Negative'] = Cision_Aggre_Data['Negative'].fillna(0)
    Cision_Aggre_Data['Neutral'] = Cision_Aggre_Data['Neutral'].fillna(0)
    
    
    #forCTA
    stackdf_CTA = stackdf_CTA.sentiment.rename_axis([None], axis=1)
    Cision_CTAAggre_Data = pd.merge(Cision_CTAAggre_Data,stackdf_CTA,left_on='Date',right_on='date',how='left')
    Cision_CTAAggre_Data = Cision_CTAAggre_Data.rename(columns={'positive':'Positive','negative':'Negative','neutral':'Neutral'})
    Cision_CTAAggre_Data['Positive'] = Cision_CTAAggre_Data['Positive'].fillna(0)
    Cision_CTAAggre_Data['Negative'] = Cision_CTAAggre_Data['Negative'].fillna(0)
    Cision_CTAAggre_Data['Neutral'] = Cision_CTAAggre_Data['Neutral'].fillna(0)
    
    
    
      #Appending CTA aggregated data to Aggregated data
    Cision_Aggre_Data = Cision_Aggre_Data.append(Cision_CTAAggre_Data,ignore_index=True)    
    #appending CTA post data to normal search post level data
    Cision_Post_Data = Cision_Post_Data.append(Cision_CTAPost_Data,ignore_index=True)
    
    #saving the dataset created to DATASETS folder
    #Make sure you have DATASETS folder created explicitly
    dirpath = './DATASETS/'
    Cision_Post_Data.to_csv(dirpath+ct_Post_exist_file+enddate+'.csv',index = False,date_format='%m/%d/%Y')
    Cision_Aggre_Data.to_csv(dirpath+ct_Aggre_exist_file+enddate+'.csv',index = False,date_format='%m/%d/%Y')
    print('File Saved!!')  

print('\n\n')
print('#################################################################################################\n')
print('DATA EXTRACTING FOR CROWDTANGLE')

#API Calls to get posts
if(Crowdtangle_postlevel[-1] == 'File already present'):
    ig_df = Crowdtangle_postlevel[0]
    fb_df = Crowdtangle_postlevel[1]
    ig_tid = Crowdtangle_postlevel[2]
    fb_tid = Crowdtangle_postlevel[3]
    ig_published_startdate = Crowdtangle_postlevel[4]
    fb_published_startdate = Crowdtangle_postlevel[5]
    published_enddate = Crowdtangle_postlevel[6]
    user_topic = Crowdtangle_postlevel[7]
    
 

    #for historic data
    ig_df_post_data = CTAPIcall(ig_access_token,ig_df,ig_tid,ig_published_startdate,published_enddate,user_topic)
    fb_df_post_data = CTAPIcall(fb_access_token,fb_df,fb_tid,fb_published_startdate,published_enddate,user_topic)
    Crowdtangle_Post_Data=ig_df_post_data.append(fb_df_post_data,ignore_index=True)
    
    dirpath = './DATASETS/'
    Crowdtangle_Post_Data.to_csv(dirpath+c_Post_exist_file,index = False ,date_format='%Y-%m-%d %H:%M:%S')
    print('File Saved!!')   
    
else:
    ig_tid = Crowdtangle_postlevel[0]
    fb_tid= Crowdtangle_postlevel[1]
    # print("IGTopicID",ig_tid)
    # print("FBTopicID",fb_tid)
    published_startdate = Crowdtangle_postlevel[2]
    published_enddate = Crowdtangle_postlevel[3]
    user_topic = Crowdtangle_postlevel[4]

 

    ig_df_post_data = CTapi(ig_access_token,ig_tid,published_startdate,published_enddate,user_topic)
    fb_df_post_data = CTapi(fb_access_token,fb_tid,published_startdate,published_enddate,user_topic)
    df_post_data=ig_df_post_data.append(fb_df_post_data,ignore_index=True)
#     df_post_data = df_post_data.reset_index()
#     df_post_data = df_post_data.rename(columns = {"level_0" : "index"})
    Crowdtangle_Post_Data = df_post_data
    dirpath = './DATASETS/'
    Crowdtangle_Post_Data.to_csv(dirpath+c_Post_exist_file+enddate+'.csv',date_format='%Y-%m-%d %H:%M:%S', index = False)
    print('File Saved!!')