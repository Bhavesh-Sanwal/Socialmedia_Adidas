
import requests
from pandas.io.json import json_normalize
from pandas import DataFrame
import pandas as pd 
import time
from datetime import datetime

def topic_dataset(access_token):


    req = requests.get('https://api.talkwalker.com/api/v1/search/info?access_token='+access_token)


    #creating project ID data set
    df_prod_id = pd.DataFrame(columns=['Account_Name','Project_Name','Project_ID'])
    num = 0
    prod_id = req.json()['result_accinfo']['projects'] 
    for i in range(len(prod_id)):
        df_prod_id.loc[num]=''
        df_prod_id['Account_Name'][num] = prod_id[i]['account_name']
        df_prod_id['Project_Name'][num] = prod_id[i]['name']
        df_prod_id['Project_ID'][num] = prod_id[i]['id']
        num +=1

    #creating DataFrame containing all data till topic ID
    num_t = 0
    topic_df = pd.DataFrame(columns=['Project_Name','Project_ID','Topic_Parent_ID','Topic_Parent_Name','Topic','Topic_ID'])
    for prod in range(len(df_prod_id['Project_ID'])):
        id = df_prod_id['Project_ID'][prod]
        #Fetching all topics from project id
        req_prodid_info = requests.get('https://api.talkwalker.com/api/v2/talkwalker/p/'+id+'/resources?access_token='+access_token)
        #project contains dict in which we have topics 
        topic = req_prodid_info.json()["result_resources"]['projects']
        for i in range(len(topic)):
            try:
                topic_list = topic[i]['topics']
                #adding parent id and name so that we know from which parent the topic is coming
                for j in range(len(topic_list)):
                    #so we have parent id under which we have nodes in which we have individual topics
                    topic_node_list = topic_list[j]['nodes']
                    for k in range(len(topic_node_list)):
                        topic_df.loc[num_t]=''
                        topic_df['Project_ID'][num_t]= topic[i]['id']
                        topic_df['Project_Name'][num_t]= topic[i]['title']
                        topic_df['Topic_Parent_ID'][num_t]= topic_list[j]['id']
                        topic_df['Topic_Parent_Name'][num_t]= topic_list[j]['title']
                        topic_df['Topic_ID'][num_t] = topic_node_list[k]['id']
                        topic_df['Topic'][num_t] = topic_node_list[k]['title']
                        num_t +=1
            except:
                    continue

    topic_df.to_csv('TopicID_Dataset.csv')

