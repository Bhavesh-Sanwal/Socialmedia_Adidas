# -*- coding: utf-8 -*-
import requests
import pandas as pd


def topic_datasetCT(ig_access_token, fb_access_token):
    
    #Getting TopicIDList with title
    ig_TopicIdList = requests.get('https://api.crowdtangle.com/lists?token='+ig_access_token)
    fb_TopicIdList = requests.get('https://api.crowdtangle.com/lists?token='+fb_access_token)
    ##Creating Instagram ListData
    #Converting json to Df
    ig_df_id = pd.DataFrame(columns=['Type','Topic_Id','Topic_title'])
    types = ['SAVED_SEARCH','LIST']
    ig_ids = ig_TopicIdList.json()['result']['lists']
    num = 0
    for i in range(len(ig_ids)):
      if(ig_ids[i]['type'] in types):
        ig_df_id.loc[num] = ''
        ig_df_id['Type'][num] = ig_ids[i]['type']
        ig_df_id['Topic_Id'][num] = ig_ids[i]['id']
        ig_df_id['Topic_title'][num] = ig_ids[i]['title']
    
        num +=1
    
        
    print("File is Created!!")
    #Writing Ids dataFrame to csv 
    ig_df_id.to_csv('TopicIDs_IG_CrowdTangle.csv')
    
    
    ##Creating Facebook ListData
    fb_df_id = pd.DataFrame(columns=['Type','Topic_Id','Topic_title'])
    types = ['SAVED_SEARCH','LIST']
    fb_ids = fb_TopicIdList.json()['result']['lists']
    num = 0
    for i in range(len(fb_ids)):
      if(fb_ids[i]['type'] in types):
        fb_df_id.loc[num] = ''
        fb_df_id['Type'][num] = fb_ids[i]['type']
        fb_df_id['Topic_Id'][num] = fb_ids[i]['id']
        fb_df_id['Topic_title'][num] = fb_ids[i]['title']
    
        num +=1
    
        
    print("File is Created!!")
    #Writing Ids dataFrame to csv 
    fb_df_id.to_csv('TopicIDs_FB_CrowdTangle.csv')
    


