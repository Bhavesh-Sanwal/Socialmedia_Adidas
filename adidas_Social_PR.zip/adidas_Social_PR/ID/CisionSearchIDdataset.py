from datetime import datetime, timedelta
import re
import pandas as pd
import time
import requests
from utils.Cisionaccesstoken import accessToken


def searchidData():
    auth_token = accessToken()
    df = pd.DataFrame(columns=['id','title','taxonomy'])
    
    headers = {
      'X-Auth-Token': auth_token ,
    }

    url = "https://api.trendkite.com/api/v2/searches"

    response = requests.get(url, headers=headers)

    data = response.json()
    datalist = data['searches']
    #creating dataset of id and title from json response
    num = 0
    for i in datalist:
        df.loc[num]=''
        for key,value in i.items():
            df[key][num] = i[key]
            
        num +=1
    
    df.to_csv('Cision_Search_ID_Dataset.csv',index = False)
        