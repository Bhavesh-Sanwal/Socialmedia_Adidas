import requests
from pandas.io.json import json_normalize
from pandas import DataFrame
import pandas as pd 
import time
from datetime import datetime
import os.path
from dateutil import tz
import re
from datetime import datetime, timedelta
from datetime import date

#Not added for Time conversion from any time to CET dateconversion module need to be added later
#this method returns true if file exists
def checkFile(fn):
    pathdir = './DATASETS/'
    return os.path.isfile(pathdir+fn)


def historicDataRefresh(df):

    ''' Check for the file FirstExecution if the file is not present then it will ask for the no. of days 
    data need to be refresed but if the file is present it will only refresh the most recent data'''
    df = df
    path = 'temp'
    list_dir = []
    if(os.path.exists(path)):
       list_dir =  os.listdir(path)
    if(not os.path.exists(path)):
        os.mkdir('temp')
        
    #File has two sets of data one normal post level another CTA data both are differentiated by boolean column
    post_df = df[df['CTA'] == False].sort_values(by=['date'])
    cta_df = df[df['CTA'] == True].sort_values(by=['date'])
    
    
    
     #considering todays date and checking if the file is run once today or not
    if ('Cision_PostLevel_'+date.today().strftime('%d_%m_%Y')+".txt" in list_dir):
        print('second Execution')
        #THIS LOGIC IS DIFFERENT as CSV was saving in 11/7/2020 and reading in 2020-07-11
        # df['date'] = df['date'].apply(lambda x: datetime.strptime(x,'%m/%d/%y').strftime('%Y-%m-%d'))
        #converting all values in date to one format
        
        post_df['date'] =post_df['date'].apply(lambda x: datetime.strptime(x,'%m/%d/%Y').strftime('%Y-%m-%d'))
        cta_df['date'] =cta_df['date'].apply(lambda x: datetime.strptime(x,'%m/%d/%Y').strftime('%Y-%m-%d'))
        # for i in range(len(df['date'])):
        #     try:
        #         df['date'][i] = datetime.strptime(df['date'][i],'%m/%d/%y').strftime('%Y-%m-%d')
        #     except:
        #         #pass because its already in same format
        #         pass

        post_date = post_df['date'].iloc[-1]
        cta_date = cta_df['date'].iloc[-1]
        
        # dates = df['date'].iloc[-1]

        #extracting date from datatime
        post_new_start_date = datetime.strptime(post_date ,'%Y-%m-%d') - timedelta(days=0)
        cta_new_start_date = datetime.strptime(cta_date ,'%Y-%m-%d') - timedelta(days=0)
        print('Refreshing post data from: '+datetime.strftime(post_new_start_date,'%Y-%m-%d'))
        print('Refreshing cta data from: '+datetime.strftime(cta_new_start_date,'%Y-%m-%d'))
        
        post_df['date'] = post_df['date'].apply(lambda x: datetime.strptime(x,'%Y-%m-%d'))
        cta_df['date'] = cta_df['date'].apply(lambda x: datetime.strptime(x,'%Y-%m-%d'))
        
        
        post_df_modified = post_df[post_df['date'] < post_new_start_date]
        cta_df_modified = cta_df[cta_df['date'] < cta_new_start_date]
        
        #converting date again to string format
        post_df_modified['date'] = post_df_modified['date'].apply(lambda x: datetime.strftime(x,'%Y-%m-%d'))
        post_sname = post_df_modified['searchName'].iloc[1]
        
        cta_df_modified['date'] = cta_df_modified['date'].apply(lambda x: datetime.strftime(x,'%Y-%m-%d'))
        cta_sname = cta_df_modified['searchName'].iloc[1]
        tup = (post_df_modified,datetime.strftime(post_new_start_date,'%Y-%m-%d'),post_sname,cta_df_modified,datetime.strftime(cta_new_start_date,'%Y-%m-%d'),cta_sname)
        
        return tup
    
    else:
        #Create a file after 1st execution.
        file = open(os.path.join(path,"Cision_PostLevel_"+date.today().strftime('%d_%m_%Y')+".txt"), 'w')
        file.write("First Execution")
        file.close()
        print('First execution')
        
        #python is reading the date column in other format and saving it in other format 
        #cta_df['date'] = cta_df['date'].apply(lambda x: datetime.strptime(x,'%m/%d/%y').strftime('%m/%d/%Y'))
        
        post_df['date'] =post_df['date'].apply(lambda x: datetime.strptime(x,'%m/%d/%Y').strftime('%Y-%m-%d'))
        cta_df['date'] =cta_df['date'].apply(lambda x: datetime.strptime(x,'%m/%d/%Y').strftime('%Y-%m-%d'))
        # for i in range(len(post_df['date'])):
        #     try:
        #         post_df['date'][i] = datetime.strptime(post_df['date'][i],'%m/%d/%Y').strftime('%Y-%m-%d')
        #     except:
        #         #pass because its already in same format
        #         pass
            
        # for j in range(len(cta_df['date'])):
        #     try:
        #         'Date is 11/01/20 to using y else use Y if have 2020 instead of 20'
        #         cta_df['date'][j] = datetime.strptime(cta_df['date'][j],'%m/%d/%Y').strftime('%Y-%m-%d')
        #     except:
        #         #pass because its already in same format
        #         pass
        # df['date'] = df['date'].apply(lambda x: datetime.strptime(x,'%m/%d/%y').strftime('%Y-%m-%d'))

        post_date = post_df['date'].iloc[-1]
        cta_date = cta_df['date'].iloc[-1]
        #extracting date from datatime
        day = int(input('Number of days data need to be refreshed: '))
        post_new_start_date = datetime.strptime(post_date ,'%Y-%m-%d') - timedelta(days=day)
        cta_new_start_date = datetime.strptime(cta_date ,'%Y-%m-%d') - timedelta(days=day)
        
        print('Refreshing post data from: '+datetime.strftime(post_new_start_date,'%Y-%m-%d'))
        print('Refreshing cta data from: '+datetime.strftime(cta_new_start_date,'%Y-%m-%d'))
        
        post_df['date'] = post_df['date'].apply(lambda x: datetime.strptime(x,'%Y-%m-%d'))
        cta_df['date'] = cta_df['date'].apply(lambda x: datetime.strptime(x,'%Y-%m-%d'))
        
        post_df_modified = post_df[post_df['date'] < post_new_start_date]
        cta_df_modified = cta_df[cta_df['date'] < cta_new_start_date]
        
        #converting date again to string format
        post_df_modified['date'] = post_df_modified['date'].apply(lambda x: datetime.strftime(x,'%Y-%m-%d'))
        post_sname = post_df_modified['searchName'].iloc[1]
        
        cta_df_modified['date'] = cta_df_modified['date'].apply(lambda x: datetime.strftime(x,'%Y-%m-%d'))
        cta_sname = cta_df_modified['searchName'].iloc[1]
        
        tup = (post_df_modified,datetime.strftime(post_new_start_date,'%Y-%m-%d'),post_sname,cta_df_modified,datetime.strftime(cta_new_start_date,'%Y-%m-%d'),cta_sname)

        return tup


def returnUserInputsPostlevelCision(searchname,startdate,enddate,ct_Post_exist_file,cta_name):
    #if already have a file
    fname = ct_Post_exist_file

    if(checkFile(fname)):

        pathdir = './DATASETS/'
        df = pd.read_csv(pathdir+fname)
        
        df['date'] = pd.to_datetime(df['date'])
        df['date'] = df['date'].apply(lambda x: datetime.strftime(x,'%m/%d/%Y'))
        
        searchid_df = pd.read_csv('Cision_Search_ID_Dataset.csv')
        #this will return tuple of two values
        returned_data = historicDataRefresh(df)
        
        post_dfs = returned_data[0]
        post_startdate = returned_data[1]
        post_search_name = returned_data[2]
        cta_dfs = returned_data[3]
        cta_startdate = returned_data[4]
        cta_search_name = returned_data[5]
        # incrementing a day so that we dont have duplicate values 
        # startdate = (datetime.strptime(startdate,'%Y-%m-%d') + timedelta(days= 1)).strftime('%Y-%m-%d')+'T00:00:00.000Z'
        enddate = enddate
        enddate = datetime.strptime(enddate,'%d-%m-%Y').strftime('%Y-%m-%d')
        postsearchid = post_dfs['searchId'].iloc[-1]  
        ctasearchid = cta_dfs['searchId'].iloc[-1] 

        tuple_return = (postsearchid,ctasearchid,post_startdate,cta_startdate,enddate,post_dfs,cta_dfs,post_search_name,cta_search_name,'File already present')

        return tuple_return

    else:
        #reading the csv file for selecting the project , topic (another module to create this topicID dataset)
        #DO NOT CHANGE THE NAME
        searchid_df = pd.read_csv('Cision_Search_ID_Dataset.csv')
        cta_searchid_df = pd.read_csv('Cision_CTA_ID.csv')
        #input project name and then topic to get topic id under particualr project 
        user_searchname = searchname
        #subseting DF to have searchid and search name
        searchid_df['condition'] = searchid_df.apply(lambda x: x['title']== user_searchname.strip() ,axis = 1)
        search_id = searchid_df[searchid_df['condition'] == True]['id']
        search_sid = ''
        search_name = ''
        for items in search_id.iteritems(): 
            search_sid = items[1]
        #to get the title also
        search_n = searchid_df[searchid_df['condition'] == True]['title']
        for items in search_n.iteritems():
            search_name = items[1]
            
            
        #subseting DF to have cta_id 
        cta_searchid_df['condition'] = cta_searchid_df.apply(lambda x: x['title']== cta_name.strip() ,axis = 1)
        cta_id = cta_searchid_df[cta_searchid_df['condition'] == True]['id']
        ctaid=''
        for items in cta_id.iteritems(): 
            ctaid = items[1]

        
        startdate = startdate
        #Converting to other format
        startdate = datetime.strptime(startdate,'%d-%m-%Y').strftime('%Y-%m-%d')

        enddate = enddate
        #Converting to other format
        enddate = datetime.strptime(enddate,'%d-%m-%Y').strftime('%Y-%m-%d')

        tuple_return = (search_sid,startdate,enddate,search_name,ctaid,cta_name)
        
        return tuple_return