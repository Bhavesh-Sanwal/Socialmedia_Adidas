import requests
from pandas.io.json import json_normalize
from pandas import DataFrame
import pandas as pd 
import time
from datetime import datetime
import os.path
from dateutil import tz
import re
from datetime import datetime, timedelta
from datetime import date


#this method returns true if file exists
def checkFile(fn):
    pathdir = './DATASETS/'
    return os.path.isfile(pathdir+fn)


def historicDataRefresh(df):

    ''' Check for the file FirstExecution if the file is not present then it will ask for the no. of days 
    data need to be refresed but if the file is present it will only refresh the most recent data'''

    path = 'temp'
    list_dir = []
    if(os.path.exists(path)):
       list_dir =  os.listdir(path)
    if(not os.path.exists(path)):
        os.mkdir('temp')
        
    #post df = data for aggregated df 
    #cta_df = data for CTA aggregated df
    
    post_df = df[df['CTA'] == False].sort_values(by=['startDate'])
    cta_df = df[df['CTA'] == True].sort_values(by=['startDate'])
    cta_df = cta_df.reset_index().drop(['index'],axis = 1)
    
     #considering todays date and checking if the file is run once today or not
    if ('Cision_AggreLevel_'+date.today().strftime('%d_%m_%Y')+".txt" in list_dir):
        print('second Execution')
        dates = post_df['startDate'].iloc[-1]
        ctadate = cta_df['startDate'].iloc[-1]
        #extracting date from datatime
        dates = dates.split('T')[0]
        ctadate = ctadate.split('T')[0]
        
        
        
        new_start_date = datetime.strptime(dates ,'%Y-%m-%d') - timedelta(days=0)
        cta_new_start_date = datetime.strptime(ctadate ,'%Y-%m-%d') - timedelta(days=0)
        
        print('Refreshing data from: '+datetime.strftime(new_start_date,'%Y-%m-%d'))
        print('Refreshing CTA Aggregated data from: '+datetime.strftime(cta_new_start_date,'%Y-%m-%d'))
        
        #splitting x on . because of millsecond 
        post_df['startDate'] = post_df['startDate'].apply(lambda x: datetime.strptime(x.split('.')[0],'%Y-%m-%dT%H:%M:%S'))
        post_df_modified = post_df[post_df['startDate'] < new_start_date]
        #after removing the records converting back to the actual format
        post_df_modified['startDate'] = post_df_modified['startDate'].apply(lambda x: datetime.strftime(x,'%Y-%m-%dT%H:%M:%S'))
        post_df_modified['startDate'] = post_df_modified['startDate'].apply(lambda x: x+'.000Z')
        #new start date
        newdate = datetime.strftime(new_start_date,'%Y-%m-%dT%H:%M:%S')
        newdate = newdate+'.000Z'
        
        #for CTA 
        #splitting x on . because of millsecond 
        cta_df['startDate'] = cta_df['startDate'].apply(lambda x: datetime.strptime(x.split('.')[0],'%Y-%m-%dT%H:%M:%S'))
        cta_df_modified = cta_df[cta_df['startDate'] < cta_new_start_date]
        #after removing the records converting back to the actual format
        cta_df_modified['startDate'] = cta_df_modified['startDate'].apply(lambda x: datetime.strftime(x,'%Y-%m-%dT%H:%M:%S'))
        cta_df_modified['startDate'] = cta_df_modified['startDate'].apply(lambda x: x+'.000Z')

        # #new start date
        # cta_newdate = datetime.strftime(cta_new_start_date,'%Y-%m-%dT%H:%M:%S')
        # cta_newdate = cta_newdate+'.000Z'
        
        tup = (post_df_modified,newdate,cta_df_modified)
        
        return tup

    else:
        #Create a file after 1st execution.
        file = open(os.path.join(path,"Cision_AggreLevel_"+date.today().strftime('%d_%m_%Y')+".txt"), 'w')
        file.write("First Execution")
        file.close()
        print('First execution')
        
        dates = post_df['startDate'].iloc[-1]
        ctadate = cta_df['startDate'].iloc[-1]
        #extracting date from datatime
        dates = dates.split('T')[0]
        ctadate = ctadate.split('T')[0]
        
        day = int(input('Number of days data need to be refreshed: '))
        
        new_start_date = datetime.strptime(dates ,'%Y-%m-%d') - timedelta(days=day)
        cta_new_start_date = datetime.strptime(ctadate ,'%Y-%m-%d') - timedelta(days=day)
        
        print('Refreshing Aggregated data from: '+datetime.strftime(new_start_date,'%Y-%m-%d'))
        print('Refreshing CTA Aggregated data from: '+datetime.strftime(cta_new_start_date,'%Y-%m-%d'))
        
        #splitting x on . because of millsecond 
        post_df['startDate'] = post_df['startDate'].apply(lambda x: datetime.strptime(x.split('.')[0],'%Y-%m-%dT%H:%M:%S'))
        post_df_modified = post_df[post_df['startDate'] < new_start_date]
        #after removing the records converting back to the actual format
        post_df_modified['startDate'] = post_df_modified['startDate'].apply(lambda x: datetime.strftime(x,'%Y-%m-%dT%H:%M:%S'))
        post_df_modified['startDate'] = post_df_modified['startDate'].apply(lambda x: x+'.000Z')

        #new start date
        newdate = datetime.strftime(new_start_date,'%Y-%m-%dT%H:%M:%S')
        newdate = newdate+'.000Z'
        
        
        #for CTA 
        #splitting x on . because of millsecond 
        cta_df['startDate'] = cta_df['startDate'].apply(lambda x: datetime.strptime(x.split('.')[0],'%Y-%m-%dT%H:%M:%S'))
        cta_df_modified = cta_df[cta_df['startDate'] < cta_new_start_date]
        #after removing the records converting back to the actual format
        cta_df_modified['startDate'] = cta_df_modified['startDate'].apply(lambda x: datetime.strftime(x,'%Y-%m-%dT%H:%M:%S'))
        cta_df_modified['startDate'] = cta_df_modified['startDate'].apply(lambda x: x+'.000Z')

        # #new start date
        # cta_newdate = datetime.strftime(cta_new_start_date,'%Y-%m-%dT%H:%M:%S')
        # cta_newdate = cta_newdate+'.000Z'

        tup = (post_df_modified,newdate,cta_df_modified)

        return tup




def returnUserInputsAggrelevelCision(searchname,startdate,enddate,ct_Aggre_exist_file,cta_name):

    #if already have a file
    fname = ct_Aggre_exist_file

    if(checkFile(fname)):
        pathdir = './DATASETS/'
        df = pd.read_csv(pathdir+fname)
        
        
        returned_data = historicDataRefresh(df)
        dfs = returned_data[0]
        startdate = returned_data[1]
        cta_dfs =  returned_data[2]

        

        # incrementing a day so that we dont have duplicate values 
        # startdate = (datetime.strptime(startdate,'%Y-%m-%d') + timedelta(days= 1)).strftime('%Y-%m-%d')+'T00:00:00.000Z'
        enddate = enddate
        enddate = datetime.strptime(enddate,'%d-%m-%Y').strftime('%Y-%m-%d')+'T23:59:59.000Z'
        searchid = dfs['searchId'].iloc[-1]        
        ctasearchid = cta_dfs['searchId'].iloc[-1] 
        
        tuple_return = (searchid,startdate,enddate,dfs,ctasearchid,cta_dfs,'File already present')

        return tuple_return

    else:
        #reading the csv file for selecting the project , topic (another module to create this topicID dataset)
        #DO NOT CHANGE THE NAME
        searchid_df = pd.read_csv('Cision_Search_ID_Dataset.csv')
        cta_searchid_df = pd.read_csv('Cision_CTA_ID.csv')
        #search name entered by user
        user_searchname = searchname
        #subseting DF
        searchid_df['condition'] = searchid_df.apply(lambda x: x['title']== user_searchname.strip() ,axis = 1)
        search_id = searchid_df[searchid_df['condition'] == True]['id']
        search_sid = ''
        for items in search_id.iteritems(): 
            search_sid = items[1]
            
            
            
        #subseting DF to have cta_id 
        cta_searchid_df['condition'] = cta_searchid_df.apply(lambda x: x['title']== cta_name.strip() ,axis = 1)
        cta_id = cta_searchid_df[cta_searchid_df['condition'] == True]['id']
        ctaid=''
        for items in cta_id.iteritems(): 
            ctaid = items[1]
            
            
        startdate = startdate
        #Converting to other format
        startdate = datetime.strptime(startdate,'%d-%m-%Y').strftime('%Y-%m-%d')

        enddate = enddate
        #Converting to other format
        enddate = datetime.strptime(enddate,'%d-%m-%Y').strftime('%Y-%m-%d')
        tuple_return = (search_sid,startdate,enddate,ctaid)
        
        return tuple_return