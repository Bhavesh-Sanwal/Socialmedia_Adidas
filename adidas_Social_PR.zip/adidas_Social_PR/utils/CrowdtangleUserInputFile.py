# -*- coding: utf-8 -*-
import requests
from pandas.io.json import json_normalize
from pandas import DataFrame
import pandas as pd 
import time
from datetime import datetime
import os.path
from dateutil import tz
from datetime import datetime, timedelta
from datetime import date




#this method returns true if file exists
def checkFile(fn):
    pathdir = './DATASETS/'
    return os.path.isfile(pathdir+fn)

def historicDataRefresh(df):

    ''' Check for the file FirstExecution if the file is not present then it will ask for the no. of days 
    data need to be refresed but if the file is present it will only refresh the most recent data'''
    pathdir = './DATASETS/'
    path = 'temp'
    list_dir = []
    if(os.path.exists(path)):
       list_dir =  os.listdir(path)
    if(not os.path.exists(path)):
        os.mkdir('temp')
    IG_df = df[df['Source Type'] == 'Instagram'].sort_values(by=['Date'])
    FB_df = df[df['Source Type'] == 'Facebook'].sort_values(by=['Date'])
    ig_dates = IG_df['Date'].iloc[-1]
    fb_dates = FB_df['Date'].iloc[-1]
    #extracting date from datatime
    ig_dates = ig_dates.split('.')[0]
    print("ig_dates",ig_dates)
    fb_dates = fb_dates.split('.')[0]
     #considering todays date and checking if the file is run once today or not
    if ('Crowdtangle_PostLevel_'+date.today().strftime('%d_%m_%Y')+".txt" in list_dir):
        print('second Execution')

        IG_new_start_date = datetime.strptime(ig_dates.split()[0]+' 00:00:00','%Y-%m-%d %H:%M:%S') - timedelta(days=0)
        FB_new_start_date = datetime.strptime(fb_dates.split()[0]+' 00:00:00','%Y-%m-%d %H:%M:%S') - timedelta(days=0)
        
        #splitting x on . because of millsecond 
        IG_df['Date'] = IG_df['Date'].apply(lambda x: datetime.strptime(x.split('.')[0],'%Y-%m-%d %H:%M:%S'))
        ig_df_modified = IG_df[IG_df['Date'] < IG_new_start_date]
        ig_df_modified['Date'] = ig_df_modified['Date'].apply(lambda x: datetime.strftime(x,'%Y-%m-%d %H:%M:%S'))
        
        FB_df['Date'] = FB_df['Date'].apply(lambda x: datetime.strptime(x.split('.')[0],'%Y-%m-%d %H:%M:%S'))
        fb_df_modified = FB_df[FB_df['Date'] < FB_new_start_date]
        fb_df_modified['Date'] = fb_df_modified['Date'].apply(lambda x: datetime.strftime(x,'%Y-%m-%d %H:%M:%S'))
       
        return ig_df_modified,fb_df_modified

    else:
        #Create a file after 1st execution.
        file = open(os.path.join(path,"Crowdtangle_PostLevel_"+date.today().strftime('%d_%m_%Y')+".txt"), 'w')
        file.write("First Execution")
        file.close()
        print('First execution')

        day = int(input('Number of days data need to be refreshed:'))
        ig_new_start_date = datetime.strptime(ig_dates.split()[0]+' 00:00:00','%Y-%m-%d %H:%M:%S') - timedelta(days=day)
        fb_new_start_date = datetime.strptime(fb_dates.split()[0]+' 00:00:00','%Y-%m-%d %H:%M:%S') - timedelta(days=day)
        
        print('Refreshing Instagram data from: '+datetime.strftime(ig_new_start_date,'%Y-%m-%d %H:%M:%S'))
        print('Refreshing Facebook data from: '+datetime.strftime(fb_new_start_date,'%Y-%m-%d %H:%M:%S'))
        print("ig_new_start_date",ig_new_start_date)
        #splitting x on . because of millsecond 
        IG_df['Date'] = IG_df['Date'].apply(lambda x: datetime.strptime(x,'%Y-%m-%d %H:%M:%S'))
        FB_df['Date'] = FB_df['Date'].apply(lambda x: datetime.strptime(x,'%Y-%m-%d %H:%M:%S'))
      
        #FB_df['Date'] = FB_df['Date'].apply(lambda x: datetime.strptime(x.split('.')[0],'%Y-%m-%d %H:%M:%S'))
       
        IG_df_modified = IG_df[IG_df['Date'] < ig_new_start_date]
        FB_df_modified = FB_df[FB_df['Date'] < fb_new_start_date]
        print(IG_df_modified.head())
        IG_df_modified['Date'] = IG_df_modified['Date'].apply(lambda x: datetime.strftime(x,'%Y-%m-%d %H:%M:%S'))
        FB_df_modified['Date'] = FB_df_modified['Date'].apply(lambda x: datetime.strftime(x,'%Y-%m-%d %H:%M:%S'))
        
        return IG_df_modified,FB_df_modified


def CTreturnUserInputsPostlevel(ct_searchname,startdate,enddate,c_Post_exist_file):
    #if already have a file
    fname = c_Post_exist_file

    if(checkFile(fname)):

        pathdir = './DATASETS/'
        df = pd.read_csv(pathdir+fname)
        
        IG_tup,FB_tup = historicDataRefresh(df)

        print(IG_tup.head())
        #reading the csv file for selecting the project , topic 
        ig_topic_df = pd.read_csv('TopicIDs_IG_CrowdTangle.csv')
        fb_topic_df = pd.read_csv('TopicIDs_FB_CrowdTangle.csv')
        #input project name and then topic to get topic id under particualr project 
        user_topic = ct_searchname
        #subseting DF
        #topic_df['condition']=topic_df[topic_df['Topic_title']==user_topic]
        
        ig_topic_df['condition'] = ig_topic_df.apply(lambda x: x['Topic_title'] == user_topic.strip(),axis=1)
        ig_topic_tid = ig_topic_df[ig_topic_df['condition'] == True]['Topic_Id']
        ig_tid=''
        #flag = False
        for items in ig_topic_tid.iteritems(): 
           ig_tid = items[1]  
        #fB topic_ID
        fb_topic_df['condition'] = fb_topic_df.apply(lambda x: x['Topic_title'].lower() == user_topic.strip().lower(),axis=1)
        fb_topic_tid = fb_topic_df[fb_topic_df['condition'] == True]['Topic_Id']
        fb_tid=''
        #flag = False
        for items in fb_topic_tid.iteritems(): 
           fb_tid = items[1]
        
        
        #getting the last index value and taking the last  date from the df
        ig_published_startdate = str(IG_tup.iloc[-1,IG_tup.columns.get_loc("Date")])
        fb_published_startdate = str(FB_tup.iloc[-1,FB_tup.columns.get_loc("Date")])
        
        print(fb_published_startdate)
        published_enddate = enddate
        print(published_enddate)

        tuple_return = (IG_tup,FB_tup,ig_tid,fb_tid,ig_published_startdate,fb_published_startdate,
                        published_enddate,user_topic,'File already present')

        return tuple_return
 
    else:
        #print("File Doesnt Exist")
        #reading the csv file for selecting the topic(#Readyforsport) (another module to create this topicID dataset)
        ig_topic_df = pd.read_csv('TopicIDs_IG_CrowdTangle.csv')
        fb_topic_df = pd.read_csv('TopicIDs_FB_CrowdTangle.csv')
        #input project name and then topic to get topic id under particualr project 
        user_topic = ct_searchname
        #subseting DF
        #topic_df['condition']=topic_df[topic_df['Topic_title']==user_topic]
        
        ig_topic_df['condition'] = ig_topic_df.apply(lambda x: x['Topic_title'] == user_topic.strip(),axis=1)
        ig_topic_tid = ig_topic_df[ig_topic_df['condition'] == True]['Topic_Id']
        ig_tid=''
        #flag = False
        for items in ig_topic_tid.iteritems(): 
           ig_tid = items[1]
        print(ig_tid)
        #fB topic_ID
        fb_topic_df['condition'] = fb_topic_df.apply(lambda x: x['Topic_title'].lower() == user_topic.strip().lower(),axis=1)
        fb_topic_tid = fb_topic_df[fb_topic_df['condition'] == True]['Topic_Id']
        fb_tid=''
        #flag = False
        for items in fb_topic_tid.iteritems(): 
           fb_tid = items[1]
        
        published_startdate = startdate
        published_enddate = enddate
        tuple_return = (ig_tid,fb_tid,published_startdate,published_enddate,user_topic)
        
        return tuple_return
    