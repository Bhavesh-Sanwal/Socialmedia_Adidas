# #cision imports 
# from ID.CisionSearchIDdataset import  
# from utils.Cisionaccesstoken import accessToken
# from utils.CisionUserInputAggre import returnUserInputsAggrelevelCision
# from utils.CisionUserInputPostLevel import returnUserInputsPostlevelCision

#talkwalker import 
from ID.TopicDatasetTalkwalker import topic_dataset
from utils.TalkwalkerUserInputFeatureAggre import returnUserInputs
from utils.TalkwalkerUserInputFeaturePostlevel import returnUserInputsPostlevel
from AggregatedData.AggregatedDataTalkwalker import agg_histogram, historic_agg_histogram
from PostData.TalkwalkerPostLevel import api,APIcall

import requests
import pandas as pd 
import time
from datetime import datetime
import os.path

import warnings
warnings.filterwarnings("ignore")

#Globally used variables
startdate = ''
enddate = ''
Talkwalker_Aggre_Data = None
Talkwalker_Post_Data = None
Cision_Aggre_Data = None
Cision_Post_Data = None

#access token for Talkwalker
access_token = 'c83d2608-85b7-4dfb-aecf-a868bb4e0529_IoAYmOAYARaeHP1KHsfrDyLXjakhY6PFqIvxTL8oP8hVATahS1b8cyMSyYhOAkdul-cgNAPUFXnShruAiVldWNa.a5hlpsS5kdxmzdsvd5QwiJRPkWvHK2l6-8FJC5GhgcG6cwlwkpBcgyP.-1-9MrPtxN71Lj4lGmD7br6bPgI'

#to check if we have the topic dataset already created or not
topic_dataset(access_token)

print('Talkwalker:')
#TAKING USER INPUTS

#passing projectname and topic to Aggregated file to talkwalker codes
Talkwalker_user_input_tuple = returnUserInputs()
print('Inputs for Post Level')
Talkwalker_postlevel = returnUserInputsPostlevel()


## FOR TALKWALKER
if(Talkwalker_user_input_tuple[-1] == 'File already present' and Talkwalker_postlevel[-1] == 'File already present'):
    ## VALUES FOR HISTORIC AGGREGATED CALLS
    p= str(Talkwalker_user_input_tuple[0])
    t= str(Talkwalker_user_input_tuple[1])
    min_date_epoch= str(Talkwalker_user_input_tuple[2])
    max_date_epoch= str(Talkwalker_user_input_tuple[3])
    df = Talkwalker_user_input_tuple[4]
    tname = Talkwalker_user_input_tuple[5]
    
    #Return the DF
    Talkwalker_Aggre_Data = historic_agg_histogram(access_token,df,tname,min_date= min_date_epoch,max_date = max_date_epoch ,tid = t, pid= p)
    
    df = Talkwalker_postlevel[0]
    pid = Talkwalker_postlevel[1]
    tid = Talkwalker_postlevel[2]
    published_startdate = Talkwalker_postlevel[3]
    published_enddate = Talkwalker_postlevel[4]
    user_topic = Talkwalker_postlevel[5]
    
    #for historic data
    Talkwalker_Post_Data = APIcall(access_token,df,user_topic,published_startdate,published_enddate,pid,tid)
    
    #Make sure you have DATASETS folder created explicitly
    dirpath = './DATASETS/'
    Talkwalker_Post_Data.to_csv(dirpath+tw_Post_exist_file,index = False)
    Talkwalker_Aggre_Data.to_csv(dirpath+tw_Aggre_exist_file,index = False)
    print('File Saved!!')



else:
    '''Both Aggregated and Post level Data is retrieved '''
    
    ## VALUES FOR NEW AGGREGATED CALLS
    p= Talkwalker_user_input_tuple[0]
    t= Talkwalker_user_input_tuple[1]
    min_date_epoch= Talkwalker_user_input_tuple[2]
    max_date_epoch= Talkwalker_user_input_tuple[3]
    tname = Talkwalker_user_input_tuple[4]
    
    Talkwalker_Aggre_Data = agg_histogram(access_token,tname,min_date = str(min_date_epoch),max_date = str(max_date_epoch) ,tid = str(t), pid= str(p))
    
    
    pid = Talkwalker_postlevel[0]
    tid = Talkwalker_postlevel[1]
    published_startdate = Talkwalker_postlevel[2]
    published_enddate = Talkwalker_postlevel[3]
    user_topic = Talkwalker_postlevel[4]
    
    
    Talkwalker_Post_Data = api(access_token,user_topic,published_startdate,published_enddate,pid,tid)

    #Make sure you have DATASETS folder created explicitly
    dirpath = './DATASETS/'
    Talkwalker_Post_Data.to_csv(dirpath+tw_Post_exist_file+enddate+'.csv',index = False)
    Talkwalker_Aggre_Data.to_csv(dirpath+tw_Aggre_exist_file+enddate+'.csv',index = False)
    print('File Saved!!')   

# Project Name: ADIDAS & COMPETITORS MASTER
# user topic: #ReadyForSport 2020
# Enter Starting Date: 01-11-2020
# Enter Ending Date: 20-11-2020
#Talkwalker_aggre23-11-2020.csv
#Talkwalker_post23-11-2020.csv