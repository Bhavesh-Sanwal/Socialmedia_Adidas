import requests
from pandas.io.json import json_normalize
from pandas import DataFrame
import pandas as pd 
import time
from datetime import datetime
import os.path
from dateutil import tz
import re


#method if you have historic data
def APIcall(access_token,df,user_topic,published_startdate,published_enddate,pid,tid):
    published_startdate = published_startdate
    published_enddate = published_enddate
    project_id = pid
    topic_id = tid
    user_topic = user_topic
    df_post_data = df
    hpp = '500'
    access_token = access_token
    # num = df.iloc[-1]['index']+1
    num = int(df.shape[0])
    count = 0
    pagination_flag = True
    while(pagination_flag):
    # while (len(search_req.json()['result_content'])!=0): #check for this condition
        search_req = requests.get('https://api.talkwalker.com/api/v1/search/p/'+project_id+'/results?access_token='+access_token+'&timezone=Europe/Berlin&topic='+topic_id+'&q=searchindexed:>'+published_startdate+'%20AND%20searchindexed:<'+published_enddate+'&hpp='+hpp+'&sort_by=search_indexed&sort_order=asc&pretty=true')
        published_startdate= str(search_req.json()['result_content']['data'][-1]['data']["search_indexed"])
        print('Search Indexed new start:',published_startdate)
        hpp_new = str(len(search_req.json()['result_content']['data']))
        print('Records Retrived:',hpp_new)
        data = search_req.json()['result_content']['data']

        for i in range(len(data)):

            df_post_data.loc[num] = ""
            df_post_data['Tool'][num] = 'Talkwalker'
            df_post_data['Domain'][num] = 'Social'
            #if social media is twitter 
            if (data[i]['data']["source_type"][1] == 'SOCIALMEDIA_TWITTER'):

                df_post_data['TW_Epoch_Time'][num] = 'x'+str(data[i]['data']['search_indexed'])
                df_post_data['Topic'][num] = user_topic
                df_post_data['TW_search_indexed'][num] = 'x'+str(data[i]['data']['search_indexed'])
                df_post_data['TW_external_author_id'][num] = 'x'+str(data[i]['data']['external_author_id'])
                df_post_data['TW_external_id'][num] = 'x'+str(data[i]['data']['external_id'])
                df_post_data['TW_Sentiment'][num] = data[i]['data']['sentiment']
                df_post_data['TW_fluency_level'][num] = data[i]['data']["fluency_level"]
                df_post_data['Source Type'][num] = data[i]['data']["source_type"][1]
                df_post_data['TW_Parent URL'][num] = 'https://twitter.com/twitter/status/'+str(data[i]['data']['external_id'])
            else:
                df_post_data['TW_Epoch_Time'][num] = 'x'+str(data[i]['data']["published"])
                df_post_data['Topic'][num] = user_topic
                df_post_data['TW_search_indexed'][num] = 'x'+str(data[i]['data']['search_indexed'])
                df_post_data['Source Type'][num] = data[i]['data']["source_type"][1]
                df_post_data['TW_Parent URL'][num] = data[i]['data']["parent_url"]
                df_post_data['Handle/Name'][num] = data[i]['data']['extra_source_attributes']['name']
                df_post_data['TW_latitude'][num] = data[i]['data']['extra_source_attributes']['world_data']["latitude"]
                df_post_data['TW_longitude'][num] = data[i]['data']['extra_source_attributes']['world_data']["longitude"]
                df_post_data['TW_fluency_level'][num] = data[i]['data']["fluency_level"]
                df_post_data['TW_lang'][num] = data[i]['data']["lang"]
                df_post_data['post_type'][num] = data[i]['data']["post_type"][0]
                df_post_data['TW_country'][num] = data[i]['data']['extra_source_attributes']['world_data']["country"]
                df_post_data['TW_continent'][num] = data[i]['data']['extra_source_attributes']['world_data']["continent"]
                df_post_data['TW_city'][num] = data[i]['data']['extra_source_attributes']['world_data']["city"]
                df_post_data['TW_country_code'][num] = data[i]['data']['extra_source_attributes']['world_data']['country_code']
                df_post_data['TW_Engagement'][num] = data[i]['data']["engagement"]
                df_post_data['TW_Reach'][num] = data[i]['data']["reach"]
                df_post_data['TW_Sentiment'][num] = data[i]['data']['sentiment']
                try:
                    if(data[i]['data']["article_extended_attributes"]):
                        for key,value in data[i]['data']["article_extended_attributes"].items():
                            df_post_data[key][num] = data[i]['data']["article_extended_attributes"][key]
                except:
                    pass

            num +=1
        count+=1
    #to check weather next api call is there or not we see for the 
        if ('next' not in search_req.json()['pagination'].keys()):
            pagination_flag = False
        print('Iteration count:',count)

    df_post_data['Timestamp']=df_post_data['TW_search_indexed'].apply(lambda x: datetime.fromtimestamp(float(re.sub('x','',x))/1000.))
    df_post_data['Timestamp_IST']=df_post_data['TW_search_indexed'].apply(lambda x: time.strftime("%a, %d %b %Y %H:%M:%S %Z", time.localtime(float(re.sub('x','',x))/1000)))

    return df_post_data

#method if you dont have historic data
def api(access_token,user_topic,published_startdate,published_enddate,pid,tid):
    df_post_data = pd.DataFrame(columns=['Tool','Domain','TW_Epoch_Time','TW_search_indexed','Handle/Name','Topic','Source Type','TW_Parent URL','TW_Engagement','TW_Reach','TW_Sentiment','SR_tweet_text','Retweets','Quote','Likes','SR_retweetby','Orignal/Retweeted','TW_external_author_id','TW_external_id','TW_fluency_level','TW_lang','post_type','TW_country','TW_continent','TW_city','TW_latitude','TW_longitude','TW_country_code','facebook_shares','facebook_likes','twitter_retweets','twitter_shares','twitter_likes','twitter_followers','vkontakte_likes','vkontakte_shares','num_comments','youtube_dislikes','youtube_likes','youtube_views','url_views,','pinterest_likes','pinterest_pins','pinterest_repins','linkedin_shares','linkedin_likes','dailymotion_views'])
    published_startdate = published_startdate
    published_enddate = published_enddate
    project_id = pid
    topic_id = tid
    user_topic =user_topic
    access_token = access_token
    hpp = '500'
    
    num = 0
    count = 0
    pagination_flag = True
    while(pagination_flag):
    # while (len(search_req.json()['result_content'])!=0): #check for this condition
        search_req = requests.get('https://api.talkwalker.com/api/v1/search/p/'+project_id+'/results?access_token='+access_token+'&timezone=Europe/Berlin&topic='+topic_id+'&q=searchindexed:>'+published_startdate+'%20AND%20searchindexed:<'+published_enddate+'&hpp='+hpp+'&sort_by=search_indexed&sort_order=asc&pretty=true')
        
        published_startdate= str(search_req.json()['result_content']['data'][-1]['data']["search_indexed"])
        print('Search Indexed new start:',published_startdate)
        hpp_new = str(len(search_req.json()['result_content']['data']))
        print('Records Retrived:',hpp_new)
        data = search_req.json()['result_content']['data']

        for i in range(len(data)):

            df_post_data.loc[num] = ""
            df_post_data['Tool'][num] = 'Talkwalker'
            df_post_data['Domain'][num] = 'Social'
            #if social media is twitter 
            if (data[i]['data']["source_type"][1] == 'SOCIALMEDIA_TWITTER'):

                df_post_data['TW_Epoch_Time'][num] = 'x'+str(data[i]['data']['search_indexed'])
                df_post_data['Topic'][num] = user_topic
                df_post_data['TW_search_indexed'][num] = 'x'+str(data[i]['data']['search_indexed'])
                df_post_data['TW_external_author_id'][num] = 'x'+str(data[i]['data']['external_author_id'])
                df_post_data['TW_external_id'][num] = 'x'+str(data[i]['data']['external_id'])
                df_post_data['TW_Sentiment'][num] = data[i]['data']['sentiment']
                df_post_data['TW_fluency_level'][num] = data[i]['data']["fluency_level"]
                df_post_data['Source Type'][num] = data[i]['data']["source_type"][1]
                df_post_data['TW_Parent URL'][num] = 'https://twitter.com/twitter/status/'+str(data[i]['data']['external_id'])
            else:
                df_post_data['TW_Epoch_Time'][num] = 'x'+str(data[i]['data']["published"])
                df_post_data['Topic'][num] = user_topic
                df_post_data['TW_search_indexed'][num] = 'x'+str(data[i]['data']['search_indexed'])
                df_post_data['Source Type'][num] = data[i]['data']["source_type"][1]
                df_post_data['TW_Parent URL'][num] = data[i]['data']["parent_url"]
                df_post_data['Handle/Name'][num] = data[i]['data']['extra_source_attributes']['name']
                df_post_data['TW_latitude'][num] = data[i]['data']['extra_source_attributes']['world_data']["latitude"]
                df_post_data['TW_longitude'][num] = data[i]['data']['extra_source_attributes']['world_data']["longitude"]
                df_post_data['TW_fluency_level'][num] = data[i]['data']["fluency_level"]
                df_post_data['TW_lang'][num] = data[i]['data']["lang"]
                df_post_data['post_type'][num] = data[i]['data']["post_type"][0]
                df_post_data['TW_country'][num] = data[i]['data']['extra_source_attributes']['world_data']["country"]
                df_post_data['TW_continent'][num] = data[i]['data']['extra_source_attributes']['world_data']["continent"]
                df_post_data['TW_city'][num] = data[i]['data']['extra_source_attributes']['world_data']["city"]
                df_post_data['TW_country_code'][num] = data[i]['data']['extra_source_attributes']['world_data']['country_code']
                df_post_data['TW_Engagement'][num] = data[i]['data']["engagement"]
                df_post_data['TW_Reach'][num] = data[i]['data']["reach"]
                df_post_data['TW_Sentiment'][num] = data[i]['data']['sentiment']
                try:
                    if(data[i]['data']["article_extended_attributes"]):
                        for key,value in data[i]['data']["article_extended_attributes"].items():
                            df_post_data[key][num] = data[i]['data']["article_extended_attributes"][key]
                except:
                    pass

            num +=1
        count+=1
    #to check weather next api call is there or not we see for the 
        if(count%5==0):
            time.sleep(20)
        if ('next' not in search_req.json()['pagination'].keys()):
            pagination_flag = False
        print('Iteration count:',count)

    df_post_data['Timestamp']=df_post_data['TW_search_indexed'].apply(lambda x: datetime.fromtimestamp(float(re.sub('x','',x))/1000.))
    #remove this after checking on murali's Laptop
    df_post_data['Timestamp_IST']=df_post_data['TW_search_indexed'].apply(lambda x: time.strftime("%a, %d %b %Y %H:%M:%S %Z", time.localtime(float(re.sub('x','',x))/1000)))
    
    return df_post_data