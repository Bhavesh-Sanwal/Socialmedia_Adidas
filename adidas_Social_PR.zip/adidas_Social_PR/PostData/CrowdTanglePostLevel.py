# -*- coding: utf-8 -*-
import requests
import pandas as pd 
import time
import re


#method if you have historic data
def CTAPIcall(access_token,df,tid,published_startdate,published_enddate,user_topic):
    list_ids = str(tid)
    start_date = published_startdate
    start_date = re.sub(' ','T',start_date)
    end_date = published_enddate
    end_date = re.sub(' ','T',end_date)
    icount = '100'
    df_post_data = df
    #num = df.iloc[-1]['index']+1
    num = int(df.shape[0])
    count = 0
    pagination_flag = True
    while (pagination_flag):
      req_list = requests.get('https://api.crowdtangle.com/posts?token='+access_token+'&listIds='+list_ids+
                              '&count='+icount+'&startDate='+start_date+'&endDate='+end_date+'&sortBy=oldest')
      #new start date as the last value in the list of post and converting it to a format that API accepts
      #print(req_list.json())
      start_date = req_list.json()['result']['posts'][-1]['date']
      start_date = re.sub(' ','T',start_date)
      data = req_list.json()['result']['posts']
      for i in range(len(data)):
        df_post_data.loc[num]=''
        df_post_data['Tool'][num] = 'CrowdTangle'
        df_post_data['Domain'][num] = 'Social'
        df_post_data['Date'][num] = data[i]['date']
        df_post_data['Handle'][num] = data[i]['account']['handle']
        df_post_data['Topic'][num] = user_topic
        df_post_data['Source Type'][num] = data[i]['account']['platform']
        if ('postUrl' in data[i].keys()): #checking if post URL is there or not
          df_post_data['Parent URL'][num] = data[i]['postUrl']
        if('favoriteCount' in data[i]['statistics']['actual']):
            df_post_data['IG_Subscriber_count'][num] = data[i]['account']['subscriberCount']
            df_post_data['IG_Fav_comment'][num] = data[i]['statistics']['actual']['commentCount']
            df_post_data['IG_Fav_count'][num] = data[i]['statistics']['actual']['favoriteCount']
            df_post_data['IG_expected_count'][num] = data[i]['statistics']['expected']['favoriteCount']
            df_post_data['IG_expected_comment'][num] = data[i]['statistics']['expected']['commentCount']
        #add
        if('likeCount' in data[i]['statistics']['actual']):
            df_post_data['FB_like_count'][num] = data[i]['statistics']['actual']['likeCount']
            df_post_data['FB_share_count'][num] = data[i]['statistics']['actual']['shareCount']
            df_post_data['FB_comment_count'][num] = data[i]['statistics']['actual']['commentCount']
            df_post_data['FB_love_count'][num] = data[i]['statistics']['actual']['loveCount']
            df_post_data['FB_wow_count'][num] = data[i]['statistics']['actual']['wowCount']
            df_post_data['FB_haha_count'][num] = data[i]['statistics']['actual']['hahaCount']
            df_post_data['FB_sad_count'][num] = data[i]['statistics']['actual']['sadCount']
            df_post_data['FB_angry_count'][num] = data[i]['statistics']['actual']['angryCount']
            df_post_data['FB_thankful_count'][num] = data[i]['statistics']['actual']['thankfulCount']
            df_post_data['FB_care_count'][num] = data[i]['statistics']['actual']['careCount']
            df_post_data['FB_expected_like_count'][num] = data[i]['statistics']['expected']['likeCount']
            df_post_data['FB_expected_share_count'][num] = data[i]['statistics']['expected']['shareCount']
            df_post_data['FB_expected_comment_count'][num] = data[i]['statistics']['expected']['commentCount']
            df_post_data['FB_expected_love_count'][num] = data[i]['statistics']['expected']['loveCount']
            df_post_data['FB_expected_wow_count'][num] = data[i]['statistics']['expected']['wowCount']
            df_post_data['FB_expected_haha_count'][num] = data[i]['statistics']['expected']['hahaCount']
            df_post_data['FB_expected_sad_count'][num] = data[i]['statistics']['expected']['sadCount']
            df_post_data['FB_expected_angry_count'][num] = data[i]['statistics']['expected']['angryCount']
            df_post_data['FB_expected_thankful_count'][num] = data[i]['statistics']['expected']['thankfulCount']
            df_post_data['FB_expected_care_count'][num] = data[i]['statistics']['expected']['careCount']
        df_post_data['post_type'][num] = data[i]['type']
       
        num +=1
      count+=1
      if(count%5 == 0):
        time.sleep(61)
      if(len(req_list.json()['result']['pagination']) == 0):
        pagination_flag = False
      # req_list = requests.get('https://api.crowdtangle.com/posts?token='+access_token+'&listIds='+list_ids+'&count='+icount+'&startDate='+start_date_new+'&endDate='+end_date+'&sortBy=oldest')
      print(count)
     
    return df_post_data

#method if you dont have historic data
def CTapi(access_token,tid,published_startdate,published_enddate,user_topic):
    list_ids = str(tid)
    start_date = published_startdate
    start_date = re.sub(' ','T',start_date)
    end_date = published_enddate
    end_date = re.sub(' ','T',end_date)
    icount = '100'
    #ig_access_token = 'l4cNmVIw9vt5l3W1mbkW3bNjfyJZZ1tBIIZclNiF'
    #access_token = 'Tjy1H6PbWdH8KhCbQSxRqV6tuscUBde0ovgEHA0S'
    df_post_data = pd.DataFrame(columns=['Tool','Domain','Handle','Topic',
                                         'Source Type','Parent URL',
                                         'IG_Subscriber_count','IG_Fav_count','IG_Fav_comment','IG_expected_count',
                                         'IG_expected_comment','FB_like_count' ,'FB_share_count' ,'FB_comment_count' ,
                                         'FB_love_count' ,'FB_wow_count' ,'FB_haha_count' ,'FB_sad_count' ,'FB_angry_count' ,
                                         'FB_thankful_count' ,'FB_care_count' ,'FB_expected_like_count' ,'FB_expected_share_count' ,
                                         'FB_expected_comment_count' ,'FB_expected_love_count' ,'FB_expected_wow_count' ,'FB_expected_haha_count' ,
                                         'FB_expected_sad_count' ,'FB_expected_angry_count' ,'FB_expected_thankful_count' ,'FB_expected_care_count',
                                         'post_type','Date'])

    num = 0
    count = 0
    pagination_flag = True
    while (pagination_flag):
      req_list = requests.get('https://api.crowdtangle.com/posts?token='+access_token+'&listIds='+list_ids+
                              '&count='+icount+'&startDate='+start_date+'&endDate='+end_date+'&sortBy=oldest')
      #new start date as the last value in the list of post and converting it to a format that API accepts
      #print(req_list.json())
      start_date = req_list.json()['result']['posts'][-1]['date']
      start_date = re.sub(' ','T',start_date)
      data = req_list.json()['result']['posts']
      for i in range(len(data)):
        df_post_data.loc[num]=''
        df_post_data['Tool'][num] = 'CrowdTangle'
        df_post_data['Domain'][num] = 'Social'
        df_post_data['Date'][num] =data[i]['date']
        if('handle' in data[i]['account']):
            df_post_data['Handle'][num] = data[i]['account']['handle']
        df_post_data['Topic'][num] = user_topic
        df_post_data['Source Type'][num] = data[i]['account']['platform']
        if ('postUrl' in data[i].keys()): #checking if post URL is there or not
          df_post_data['Parent URL'][num] = data[i]['postUrl']
        if('favoriteCount' in data[i]['statistics']['actual']):
            df_post_data['IG_Subscriber_count'][num] = data[i]['account']['subscriberCount']
            df_post_data['IG_Fav_comment'][num] = data[i]['statistics']['actual']['commentCount']
            df_post_data['IG_Fav_count'][num] = data[i]['statistics']['actual']['favoriteCount']
            df_post_data['IG_expected_count'][num] = data[i]['statistics']['expected']['favoriteCount']
            df_post_data['IG_expected_comment'][num] = data[i]['statistics']['expected']['commentCount']
        #add
        if('likeCount' in data[i]['statistics']['actual']):
            df_post_data['FB_like_count'][num] = data[i]['statistics']['actual']['likeCount']
            df_post_data['FB_share_count'][num] = data[i]['statistics']['actual']['shareCount']
            df_post_data['FB_comment_count'][num] = data[i]['statistics']['actual']['commentCount']
            df_post_data['FB_love_count'][num] = data[i]['statistics']['actual']['loveCount']
            df_post_data['FB_wow_count'][num] = data[i]['statistics']['actual']['wowCount']
            df_post_data['FB_haha_count'][num] = data[i]['statistics']['actual']['hahaCount']
            df_post_data['FB_sad_count'][num] = data[i]['statistics']['actual']['sadCount']
            df_post_data['FB_angry_count'][num] = data[i]['statistics']['actual']['angryCount']
            df_post_data['FB_thankful_count'][num] = data[i]['statistics']['actual']['thankfulCount']
            df_post_data['FB_care_count'][num] = data[i]['statistics']['actual']['careCount']
            df_post_data['FB_expected_like_count'][num] = data[i]['statistics']['expected']['likeCount']
            df_post_data['FB_expected_share_count'][num] = data[i]['statistics']['expected']['shareCount']
            df_post_data['FB_expected_comment_count'][num] = data[i]['statistics']['expected']['commentCount']
            df_post_data['FB_expected_love_count'][num] = data[i]['statistics']['expected']['loveCount']
            df_post_data['FB_expected_wow_count'][num] = data[i]['statistics']['expected']['wowCount']
            df_post_data['FB_expected_haha_count'][num] = data[i]['statistics']['expected']['hahaCount']
            df_post_data['FB_expected_sad_count'][num] = data[i]['statistics']['expected']['sadCount']
            df_post_data['FB_expected_angry_count'][num] = data[i]['statistics']['expected']['angryCount']
            df_post_data['FB_expected_thankful_count'][num] = data[i]['statistics']['expected']['thankfulCount']
            df_post_data['FB_expected_care_count'][num] = data[i]['statistics']['expected']['careCount']
        df_post_data['post_type'][num] = data[i]['type']
    
        num +=1
      count+=1
      if(count%5 == 0):
        time.sleep(61)
      if(len(req_list.json()['result']['pagination']) == 0):
        pagination_flag = False
      # req_list = requests.get('https://api.crowdtangle.com/posts?token='+access_token+'&listIds='+list_ids+'&count='+icount+'&startDate='+start_date_new+'&endDate='+end_date+'&sortBy=oldest')
     
    
      return df_post_data
