import requests
from pandas.io.json import json_normalize
import pandas as pd 
import time
from datetime import datetime
import os.path
from dateutil import tz
import re
from datetime import datetime, timedelta
from datetime import date

#this method returns true if file exists
def checkFile(fn):
    return os.path.isfile(fn)

#date conversion function
# def dateConversion(dt):
#     min_date = str(dt.strip())
#     pattern  = '%d-%m-%Y %H:%M:%S'
#     from_zone = tz.gettz('CET')
#     to_zone = tz.gettz('Europe/Berlin')
#     cet = datetime.strptime(min_date, '%d-%m-%Y %H:%M:%S')
#     # Tell the datetime object that it's in CET time zone since 
#     # datetime objects are 'naive' by default
#     cet = cet.replace(tzinfo=from_zone)

#     # Convert time zone
#     central = cet.astimezone(to_zone)
#     central = central.strftime('%d-%m-%Y %H:%M:%S')
#     return int(time.mktime(time.strptime(central, pattern)))


def historicDataRefresh(df):

    ''' Check for the file FirstExecution_Aggregated if the file is not present then it will ask for the no. of days 
    data need to be refresed but if the file is present it will only refresh the most recent data'''

    path = 'temp'
    list_dir = []
    if(os.path.exists(path)):
       list_dir =  os.listdir(path)
    if(not os.path.exists(path)):
        os.mkdir('temp')
    #considering todays date and checking if the file is run once today or not
    if ('AggreLevel_'+date.today().strftime('%d_%m_%Y')+".txt" in list_dir):
        print('second Execution')
        dates = df['Timestamp'].iloc[-1]
        #extracting date from datatime
        dates = dates.split('.')[0]
        new_start_date = datetime.strptime(dates.split()[0]+' 00:00:00','%Y-%m-%d %H:%M:%S') - timedelta(days=0)
        print('Refreshing data from: '+datetime.strftime(new_start_date,'%Y-%m-%d %H:%M:%S'))
        #splitting x on . because of millsecond  and conveting to datetime format
        df['Timestamp'] = df['Timestamp'].apply(lambda x: datetime.strptime(x.split('.')[0],'%Y-%m-%d %H:%M:%S'))
        df_modified = df[df['Timestamp'] < new_start_date]
        #converting again to str 
        df_modified['Timestamp'] = df_modified['Timestamp'].apply(lambda x: datetime.strftime(x,'%Y-%m-%d %H:%M:%S'))

        return df_modified

    else:
        #create a temp folder and after First execution it will store the file by name along with the date 
        file = open(os.path.join(path,"AggreLevel_"+date.today().strftime('%d_%m_%Y')+".txt"), 'w')
        file.write("First Execution")
        file.close()

        dates = df['Timestamp'].iloc[-1]
        #extracting date from datatime
        dates = dates.split('.')[0]
        day = int(input('Number of days data need to be refreshed: '))
        new_start_date = datetime.strptime(dates.split()[0]+' 00:00:00','%Y-%m-%d %H:%M:%S') - timedelta(days=day)
        print('Refreshing data from: '+datetime.strftime(new_start_date,'%Y-%m-%d %H:%M:%S'))
        #splitting x on . because of millsecond  and conveting to datetime format
        df['Timestamp'] = df['Timestamp'].apply(lambda x: datetime.strptime(x.split('.')[0],'%Y-%m-%d %H:%M:%S'))
        df_modified = df[df['Timestamp'] < new_start_date]
        #converting again to str 
        df_modified['Timestamp'] = df_modified['Timestamp'].apply(lambda x: datetime.strftime(x,'%Y-%m-%d %H:%M:%S'))

        return df_modified




def returnUserInputs():
    #reading the csv file 
    fname = input('Existing Aggregated File: ')
    if(checkFile(fname)):
        print('File already Present')
        df = pd.read_csv(fname)
        #DO NOT CHANGE THE NAME
        topic_df = pd.read_csv('TopicID_Dataset.csv')
        t =''
        p=''
        #input project name and then topic to get topic id under particualr project 
        user_projectname = input('Project Name: ') 
        user_topic = input('user topic: ')
        #subseting DF
        topic_df['condition'] = topic_df.apply(lambda x: x['Topic'] == user_topic.strip() and x['Project_Name']== user_projectname.strip() ,axis = 1)
        topic_tid = topic_df[topic_df['condition'] == True]['Topic_ID']

        #if there is a topic id then only the code will execute other wise whole execution will stop
        flag = False
        for items in topic_tid.iteritems(): 
            t = items[1]
        for proj in range(len(topic_df['Project_Name'])):
            if (topic_df['Project_Name'][proj] == user_projectname.strip()):
                p = topic_df['Project_ID'][proj]
                flag = True
            if (flag):
                break
        

        dfs = historicDataRefresh(df)

        #taking starting and ending date as input and convert it to epoch time 
        min_date_epoch = re.sub('x','',str(dfs['Epoch_Time'].iloc[-1]))

        max_date = input('Enter Ending Date: ')+" 23:59:59" #hardcoded this to convert IST to CET else use 23:59: 
        # min_date_epoch = int(time.mktime(time.strptime(min_date, pattern)))
        # max_date_epoch = int(time.mktime(time.strptime(max_date, pattern))
        pattern  = '%d-%m-%Y %H:%M:%S'
        max_date_epoch = str(int(time.mktime(time.strptime(max_date, pattern))))
        tuple_return = (p,t,min_date_epoch,max_date_epoch,dfs,'File already present')
        
        return tuple_return 

    else:
        topic_df = pd.read_csv('TopicID_Dataset.csv')
        t =''
        p=''
        #input project name and then topic to get topic id under particualr project 
        user_projectname = input('Project Name: ') 
        user_topic = input('user topic: ')
        #subseting DF
        topic_df['condition'] = topic_df.apply(lambda x: x['Topic'] == user_topic.strip() and x['Project_Name']== user_projectname.strip() ,axis = 1)
        topic_tid = topic_df[topic_df['condition'] == True]['Topic_ID']

        #if there is a topic id then only the code will execute other wise whole execution will stop
        flag = False
        for items in topic_tid.iteritems(): 
            t = items[1]
        for proj in range(len(topic_df['Project_Name'])):
            if (topic_df['Project_Name'][proj] == user_projectname.strip()):
                p = topic_df['Project_ID'][proj]
                flag = True
            if (flag):
                break

        #taking starting and ending date as input and convert it to epoch time 
        min_date = input('Enter Starting Date: ')+" 00:00:00" 
        
        max_date = input('Enter Ending Date: ')+" 23:59:59" 
        pattern  = '%d-%m-%Y %H:%M:%S'

        min_date_epoch = str(int(time.mktime(time.strptime(min_date, pattern))))
        max_date_epoch = str(int(time.mktime(time.strptime(max_date, pattern))))
        tuple_return = (p,t,min_date_epoch,max_date_epoch)
        return tuple_return





