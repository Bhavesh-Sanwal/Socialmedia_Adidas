import requests
from pandas.io.json import json_normalize
from pandas import DataFrame
import pandas as pd 
import time
from datetime import datetime
import os.path
from dateutil import tz
import re
from datetime import datetime, timedelta

#this method returns true if file exists
def checkFile(fn):
    return os.path.isfile(fn)

#date conversion function
def dateConversion(dt):
    min_date = str(dt.strip())
    pattern  = '%d-%m-%Y %H:%M:%S'
    from_zone = tz.gettz('CET')
    to_zone = tz.gettz('Europe/Berlin')
    cet = datetime.strptime(min_date, '%d-%m-%Y %H:%M:%S')
    # Tell the datetime object that it's in CET time zone since 
    # datetime objects are 'naive' by default
    cet = cet.replace(tzinfo=from_zone)

    # Convert time zone
    central = cet.astimezone(to_zone)
    central = central.strftime('%d-%m-%Y %H:%M:%S')
    return int(time.mktime(time.strptime(central, pattern)))


def historicDataRefresh(df):

    ''' Check for the file FirstExecution if the file is not present then it will ask for the no. of days 
    data need to be refresed but if the file is present it will only refresh the most recent data'''

    if os.path.isfile('FirstExecution_postlevel.txt'):
        print('second Execution')
        date = df['Timestamp'].iloc[-1]
        #extracting date from datatime
        date = date.split('.')[0]
        new_start_date = datetime.strptime(date.split()[0]+' 00:00:00','%Y-%m-%d %H:%M:%S') - timedelta(days=0)
        #splitting x on . because of millsecond 
        df['Timestamp'] = df['Timestamp'].apply(lambda x: datetime.strptime(x.split('.')[0],'%Y-%m-%d %H:%M:%S'))
        df_modified = df[df['Timestamp'] < new_start_date]
        df['Timestamp'] = df['Timestamp'].apply(lambda x: datetime.strftime(x,'%Y-%m-%d %H:%M:%S'))
        return df_modified

    else:
        #Create a file after 1st execution.
        file = open("FirstExecution_postlevel.txt", "w") 
        file.write("First Execution")
        file.close()
        print('First execution')
        date = df['Timestamp'].iloc[-1]
        #extracting date from datatime
        date = date.split('.')[0]
        day = int(input('Number of days data need to be refreshed: '))
        new_start_date = datetime.strptime(date.split()[0]+' 00:00:00','%Y-%m-%d %H:%M:%S') - timedelta(days=day)
        print('Refreshing data from: '+datetime.strftime(new_start_date,'%Y-%m-%d %H:%M:%S'))
        #splitting x on . because of millsecond 
        df['Timestamp'] = df['Timestamp'].apply(lambda x: datetime.strptime(x.split('.')[0],'%Y-%m-%d %H:%M:%S'))
        df_modified = df[df['Timestamp'] < new_start_date]
        df['Timestamp'] = df['Timestamp'].apply(lambda x: datetime.strftime(x,'%Y-%m-%d %H:%M:%S'))

        return df_modified

def returnUserInputsPostlevel():

    #if already have a file
    fname = input('Existing Post level File: ')
    if(checkFile(fname)):
        df = pd.read_csv(fname)
        #reading the csv file for selecting the project , topic 
        #DO NOT CHANGE THE NAME
        topic_df = pd.read_csv('TopicID_Dataset.csv')

        #input project name and then topic to get topic id under particualr project 
        user_projectname = input('Project Name: ') 
        user_topic = input('user topic: ')
        #subseting DF
        topic_df['condition'] = topic_df.apply(lambda x: x['Topic'] == user_topic.strip() and x['Project_Name']== user_projectname.strip() ,axis = 1)
        topic_tid = topic_df[topic_df['condition'] == True]['Topic_ID']
        tid =''
        pid=''
        flag = False
        for items in topic_tid.iteritems(): 
            tid = items[1]
        for proj in range(len(topic_df['Project_Name'])):
            if (topic_df['Project_Name'][proj] == user_projectname.strip()):
                pid = topic_df['Project_ID'][proj]
                flag = True
            if (flag):
                break
        
        #calling historic data refresh method 
        dfs = historicDataRefresh(df)

        #getting the last index value and taking the last search_indexed date from the df
        #replacing x which we have concated so that data is not stored in exponential format
        published_startdate = re.sub('x','',str(dfs['TW_search_indexed'].iloc[-1]))
        published_enddate = input('Enter Ending Date: ')+" 04:29:59"

        #calling function to convert date to a format in which API accepts it 
        published_enddate = str(dateConversion(published_enddate))

        tuple_return = (dfs,pid,tid,published_startdate,published_enddate,user_topic,'File already present')

        return tuple_return

    else:
        #reading the csv file for selecting the project , topic (another module to create this topicID dataset)
        #DO NOT CHANGE THE NAME
        topic_df = pd.read_csv('TopicID_Dataset.csv')
        #input project name and then topic to get topic id under particualr project 
        user_projectname = input('Project Name: ') 
        user_topic = input('user topic: ')
        #subseting DF
        topic_df['condition'] = topic_df.apply(lambda x: x['Topic'] == user_topic.strip() and x['Project_Name']== user_projectname.strip() ,axis = 1)
        topic_tid = topic_df[topic_df['condition'] == True]['Topic_ID']
        tid =''
        pid=''
        flag = False
        for items in topic_tid.iteritems(): 
            tid = items[1]
        for proj in range(len(topic_df['Project_Name'])):
            if (topic_df['Project_Name'][proj] == user_projectname.strip()):
                pid = topic_df['Project_ID'][proj]
                flag = True
            if (flag):
                break
        published_startdate = input('Enter Starting Date: ')+" 04:30:00" #hardcoded this value For IST to CET
        #calling function to convert date to a format in which API accepts it 
        published_startdate = str(dateConversion(published_startdate))
        print(published_startdate)
        published_enddate = input('Enter Ending Date: ')+" 04:29:59" #hardcoded this value For IST to CET
        #calling function to convert date to a format in which API accepts it 
        published_enddate = str(dateConversion(published_enddate))
        print(published_enddate)

        tuple_return = (pid,tid,published_startdate,published_enddate,user_topic)
        
        return tuple_return
