import requests
from pandas.io.json import json_normalize
from pandas import DataFrame
import pandas as pd 
import time
from datetime import datetime
import re

#when have historic data
def historic_agg_histogram(access_token,df,min_date, max_date, tid, pid):

    df_mention = df
    histreq_mention= requests.get('https://api.talkwalker.com/api/v1/search/p/'+pid+'/histogram/published?access_token='+access_token+'&timezone=Europe/Berlin&topic='+tid+'&min='+min_date+'&max='+max_date+'&interval=day&pretty=true')
    json_mention = histreq_mention.json()
    #because multiple calls lead to connection error
    time.sleep(10)
    print('Data Retrived for Mentions')
    histreq_engage= requests.get('https://api.talkwalker.com/api/v1/search/p/'+pid+'/histogram/published?access_token='+access_token+'&timezone=Europe/Berlin&topic='+tid+'&min='+min_date+'&max='+max_date+'&value_type=engagement&interval=day&pretty=true')
    json_engage= histreq_engage.json()
    time.sleep(10)
    print('Data Retrived for Engagement')
    histreq_sentiment= requests.get('https://api.talkwalker.com/api/v1/search/p/'+pid+'/histogram/published?access_token='+access_token+'&timezone=Europe/Berlin&topic='+tid+'&min='+min_date+'&max='+max_date+'&breakdown=sentiment&interval=day&pretty=true')
    json_senti= histreq_sentiment.json()
    time.sleep(10)
    print('Data Retrived for Sentiment')
    histreq_reach= requests.get('https://api.talkwalker.com/api/v1/search/p/'+pid+'/histogram/published?access_token='+access_token+'&timezone=Europe/Berlin&topic='+tid+'&min='+min_date+'&max='+max_date+'&value_type=reach&interval=day&pretty=true')
    json_reach= histreq_reach.json()
    print('Data Retrived for Reach')

    num = int(df.shape[0])
    print('creating dataset')
    for i in range(len(json_mention['result_histogram']['data'])):
        
        df_mention.loc[num]="" 
        df_mention['Tool'] [num] = 'TalkWalker'  
        df_mention['Epoch_Time'][num] = 'x'+str(json_mention['result_histogram']['data'][i]['t'])
        df_mention['Mentions by day'][num] = json_mention['result_histogram']['data'][i]['v'][0]

        df_mention['Engage_count'][num] = json_engage['result_histogram']['data'][i]['val'][0]['count']
        df_mention['Engage_avg'][num] = json_engage['result_histogram']['data'][i]['val'][0]['avg']
        df_mention['Engage_max'][num] = json_engage['result_histogram']['data'][i]['val'][0]['max']
        df_mention['Engage_min'][num] = json_engage['result_histogram']['data'][i]['val'][0]['min']
        df_mention['Engage_sum'][num] = json_engage['result_histogram']['data'][i]['val'][0]['sum']


        df_mention['POSITIVE'][num] = json_senti['result_histogram']['data'][i]['v'][0]
        df_mention['NEUTRAL'][num] = json_senti['result_histogram']['data'][i]['v'][1]
        df_mention['NEGATIVE'][num] = json_senti['result_histogram']['data'][i]['v'][2]

        df_mention['Reach_count'][num] = json_reach['result_histogram']['data'][i]['val'][0]['count']
        df_mention['Reach_avg'][num] = json_reach['result_histogram']['data'][i]['val'][0]['avg']
        df_mention['Reach_max'][num] = json_reach['result_histogram']['data'][i]['val'][0]['max']
        df_mention['Reach_min'][num] = json_reach['result_histogram']['data'][i]['val'][0]['min']
        df_mention['Reach_sum'][num] = json_reach['result_histogram']['data'][i]['val'][0]['sum']
        num = num+1

    df_mention['Timestamp']=df_mention['Epoch_Time'].apply(lambda x: datetime.fromtimestamp(float(re.sub('x','',x))/1000.))    
    return df_mention



# if no historic data
def agg_histogram(access_token,min_date, max_date, tid, pid):

    df_mention = pd.DataFrame(columns = ['Tool','Epoch_Time', 'Mentions by day','Engage_count','Engage_avg',
    'Engage_max','Engage_min','Engage_sum','POSITIVE', 'NEUTRAL', 'NEGATIVE','Reach_count','Reach_avg','Reach_max','Reach_min','Reach_sum'])

    histreq_mention= requests.get('https://api.talkwalker.com/api/v1/search/p/'+pid+'/histogram/published?access_token='+access_token+'&timezone=Europe/Berlin&topic='+tid+'&min='+min_date+'&max='+max_date+'&interval=day&pretty=true')
    json_mention = histreq_mention.json()
    #because multiple calls lead to connection error
    time.sleep(10)
    print('Data Retrived for Mentions')
    histreq_engage= requests.get('https://api.talkwalker.com/api/v1/search/p/'+pid+'/histogram/published?access_token='+access_token+'&timezone=Europe/Berlin&topic='+tid+'&min='+min_date+'&max='+max_date+'&value_type=engagement&interval=day&pretty=true')
    json_engage= histreq_engage.json()
    time.sleep(10)
    print('Data Retrived for Engagement')
    histreq_sentiment= requests.get('https://api.talkwalker.com/api/v1/search/p/'+pid+'/histogram/published?access_token='+access_token+'&timezone=Europe/Berlin&topic='+tid+'&min='+min_date+'&max='+max_date+'&breakdown=sentiment&interval=day&pretty=true')
    json_senti= histreq_sentiment.json()
    time.sleep(10)
    print('Data Retrived for Sentiment')
    histreq_reach= requests.get('https://api.talkwalker.com/api/v1/search/p/'+pid+'/histogram/published?access_token='+access_token+'&timezone=Europe/Berlin&topic='+tid+'&min='+min_date+'&max='+max_date+'&value_type=reach&interval=day&pretty=true')
    json_reach= histreq_reach.json()
    print('Data Retrived for Reach')

    num = 0
    print('creating dataset')
    for i in range(len(json_mention['result_histogram']['data'])):
        
        df_mention.loc[num]="" 
        df_mention['Tool'] [num] = 'TalkWalker'    
        df_mention['Epoch_Time'][num] = 'x'+str(json_mention['result_histogram']['data'][i]['t'])
        df_mention['Mentions by day'][num] = json_mention['result_histogram']['data'][i]['v'][0]

        df_mention['Engage_count'][num] = json_engage['result_histogram']['data'][i]['val'][0]['count']
        df_mention['Engage_avg'][num] = json_engage['result_histogram']['data'][i]['val'][0]['avg']
        df_mention['Engage_max'][num] = json_engage['result_histogram']['data'][i]['val'][0]['max']
        df_mention['Engage_min'][num] = json_engage['result_histogram']['data'][i]['val'][0]['min']
        df_mention['Engage_sum'][num] = json_engage['result_histogram']['data'][i]['val'][0]['sum']


        df_mention['POSITIVE'][num] = json_senti['result_histogram']['data'][i]['v'][0]
        df_mention['NEUTRAL'][num] = json_senti['result_histogram']['data'][i]['v'][1]
        df_mention['NEGATIVE'][num] = json_senti['result_histogram']['data'][i]['v'][2]

        df_mention['Reach_count'][num] = json_reach['result_histogram']['data'][i]['val'][0]['count']
        df_mention['Reach_avg'][num] = json_reach['result_histogram']['data'][i]['val'][0]['avg']
        df_mention['Reach_max'][num] = json_reach['result_histogram']['data'][i]['val'][0]['max']
        df_mention['Reach_min'][num] = json_reach['result_histogram']['data'][i]['val'][0]['min']
        df_mention['Reach_sum'][num] = json_reach['result_histogram']['data'][i]['val'][0]['sum']

        num = num+1

    df_mention['Timestamp']=df_mention['Epoch_Time'].apply(lambda x: datetime.fromtimestamp(float(re.sub('x','',x))/1000.))    
    return df_mention








# #method for Aggregated mentions daywise 
# def agg_histogram_mentions(access_token,min_date, max_date, tid, pid):
    
#     histreq_mention= requests.get('https://api.talkwalker.com/api/v1/search/p/'+pid+'/histogram/published?access_token='+access_token+'&timezone=Europe/Berlin&topic='+tid+'&min='+min_date+'&max='+max_date+'&interval=day&pretty=true')
#     ## Mentions for a particular tokenid daywise
#     json_mention = histreq_mention.json()
#     df_mention = pd.DataFrame(columns = ['Epoch_Time', 'Mentions by day'])

#     num = 0
#     for i in range(len(json_mention['result_histogram']['data'])):
#         #print(i)
#         num = num+1
#         df_mention.loc[num]=""    
#         df_mention['Epoch_Time'][num] = json_mention['result_histogram']['data'][i]['t']
#         df_mention['Mentions by day'][num] = json_mention['result_histogram']['data'][i]['v'][0]
      
#     df_mention['Timestamp']=df_mention['Epoch_Time'].apply(lambda x: datetime.fromtimestamp(float(x)/1000.))    
#     df_mention.to_csv('Mention_hist_AugSep.csv')
#     print('Mention File Saved!!')

# #method for Aggregated engagement daywise
# def agg_histogram_engagement(access_token,min_date, max_date, tid, pid):
#     histreq_engage= requests.get('https://api.talkwalker.com/api/v1/search/p/'+pid+'/histogram/published?access_token='+access_token+'&timezone=Europe/Berlin&topic='+tid+'&min='+min_date+'&max='+max_date+'&value_type=engagement&interval=day&pretty=true')
#     json_engage= histreq_engage.json()

#     df_engage = pd.DataFrame(columns = ['Epoch_Time', 'Count_d','count','avg','max','min','sum'])

#     num = 0
#     for i in range(len(json_engage['result_histogram']['data'])):
#         #print(i)
#         num = num+1
#         df_engage.loc[num]=""    
#         df_engage['Epoch_Time'][num] = json_engage['result_histogram']['data'][i]['t']
#         df_engage['Count_d'][num] = json_engage['result_histogram']['data'][i]['v'][0]
#         df_engage['count'][num] = json_engage['result_histogram']['data'][i]['val'][0]['count']
#         df_engage['avg'][num] = json_engage['result_histogram']['data'][i]['val'][0]['avg']
#         df_engage['max'][num] = json_engage['result_histogram']['data'][i]['val'][0]['max']
#         df_engage['min'][num] = json_engage['result_histogram']['data'][i]['val'][0]['min']
#         df_engage['sum'][num] = json_engage['result_histogram']['data'][i]['val'][0]['sum']


#     df_engage['Timestamp']=df_engage['Epoch_Time'].apply(lambda x: datetime.fromtimestamp(float(x)/1000.))    
#     df_engage.to_csv('Engagement_hist_AugSep.csv')
#     print('Engagement File Saved!!')
    
# def agg_histogram_sentiment(access_token,min_date, max_date, tid, pid):
#     histreq_sentiment= requests.get('https://api.talkwalker.com/api/v1/search/p/'+pid+'/histogram/published?access_token='+access_token+'&timezone=Europe/Berlin&topic='+tid+'&min='+min_date+'&max='+max_date+'&breakdown=sentiment&interval=day&pretty=true')
#     ## Sentiment for a particular tokenid daywise
#     json_senti= histreq_sentiment.json()
#     df_sentiment = pd.DataFrame(columns = ['Epoch_Time', 'POSITIVE', 'NEUTRAL', 'NEGATIVE'])

#     num = 0
#     for i in range(len(json_senti['result_histogram']['data'])):
#         #print(i)
#         num = num+1
#         df_sentiment.loc[num]=""    
#         df_sentiment['Epoch_Time'][num] = json_senti['result_histogram']['data'][i]['t']
#         df_sentiment['POSITIVE'][num] = json_senti['result_histogram']['data'][i]['v'][0]
#         df_sentiment['NEUTRAL'][num] = json_senti['result_histogram']['data'][i]['v'][1]
#         df_sentiment['NEGATIVE'][num] = json_senti['result_histogram']['data'][i]['v'][2]


#     df_sentiment['Timestamp']=df_sentiment['Epoch_Time'].apply(lambda x: datetime.fromtimestamp(float(x)/1000.))    
#     df_sentiment.to_csv('Sentiment_hist_AugSep.csv')
#     print('Sentiment File Saved!!')
    
# def agg_histogram_reach(access_token,min_date, max_date, tid, pid):
#     histreq_reach= requests.get('https://api.talkwalker.com/api/v1/search/p/'+pid+'/histogram/published?access_token='+access_token+'&timezone=Europe/Berlin&topic='+tid+'&min='+min_date+'&max='+max_date+'&value_type=reach&interval=day&pretty=true')
#     json_reach= histreq_reach.json()

#     df_reach = pd.DataFrame(columns = ['Epoch_Time', 'Count_d','count','avg','max','min','sum'])

#     num = 0
#     for i in range(len(json_reach['result_histogram']['data'])):
#         #print(i)
#         num = num+1
#         df_reach.loc[num]=""    
#         df_reach['Epoch_Time'][num] = json_reach['result_histogram']['data'][i]['t']
#         df_reach['Count_d'][num] = json_reach['result_histogram']['data'][i]['v'][0]
#         df_reach['count'][num] = json_reach['result_histogram']['data'][i]['val'][0]['count']
#         df_reach['avg'][num] = json_reach['result_histogram']['data'][i]['val'][0]['avg']
#         df_reach['max'][num] = json_reach['result_histogram']['data'][i]['val'][0]['max']
#         df_reach['min'][num] = json_reach['result_histogram']['data'][i]['val'][0]['min']
#         df_reach['sum'][num] = json_reach['result_histogram']['data'][i]['val'][0]['sum']


#     df_reach['Timestamp']=df_reach['Epoch_Time'].apply(lambda x: datetime.fromtimestamp(float(x)/1000.))    
#     df_reach.to_csv('Reach_hist_AugSep.csv')
#     print('Reach File Saved!!')

